<?php $__env->startSection('title', 'Lease Rental Discounting'); ?>

<?php $__env->startSection('content'); ?>

<div class="text-center"><h3 style="color: whitesmoke">Apply for Lease Rental Discounting</h3></div>
<div class="container" style="margin-top: 20px">
    <form method="POST" action="<?php echo e(url('/lease_rental_discounting_form')); ?>" style="color: whitesmoke">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="name" placeholder="Enter your name (as per PAN card)" name="name" value="<?php echo e(old('name')); ?>" required>
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="email">Email address</label>
            <input type="email" class="form-control custom-mine <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" placeholder="Enter your email address" name="email" value="<?php echo e(old('email')); ?>" required>
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="phone">Phone No.</label>
            <input type="tel" pattern="[789][0-9]{9}" size="10" class="form-control custom-mine <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phone" placeholder="Enter your phone no." name="phone" value="<?php echo e(old('phone')); ?>" required>
            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
        <p><b>Employment Status</b></p>
        <select class="custom-select custom-mine" name="employmenttype" required>
            <option value="">Choose ...</option>
            <option value="Salaried" <?php echo e(old('employmenttype') == 'Salaried' ? 'selected' : ''); ?>>Salaried</option>
            <option value="Self Employed Professional" <?php echo e(old('employmenttype') == 'Self Employed Professional' ? 'selected' : ''); ?>>Self Employed Professional</option>
            <option value="Self Employed Business" <?php echo e(old('employmenttype') == 'Self Employed Business' ? 'selected' : ''); ?>>Self Employed Business</option>
        </select><br><br>

        <div class="form-group">
            <label for="netincome">Annual Income</label>
            <input type="number" min="0" step="1000" class="form-control custom-mine <?php if ($errors->has('netincome')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netincome'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="netincome" placeholder="Enter your annual income" name="netincome" value="<?php echo e(old('netincome')); ?>" required>
            <?php if ($errors->has('netincome')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netincome'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label>City</label>
            <div class="input-group">
                <select class="custom-select custom-mine selectpicker form-control" name="city" required>
                    <option value="">Choose ...</option>
                    <option value="Ahmedabad" <?php echo e(old('city') == 'Ahmedabad' ? 'selected' : ''); ?>>Ahmedabad</option>
                    <option value="Bangalore" <?php echo e(old('city') == 'Bangalore' ? 'selected' : ''); ?>>Bangalore</option>
                    <option value="Chennai" <?php echo e(old('city') == 'Chennai' ? 'selected' : ''); ?>>Chennai</option>
                    <option value="Coimbatore" <?php echo e(old('city') == 'Coimbatore' ? 'selected' : ''); ?>>Coimbatore</option>
                    <option value="Delhi" <?php echo e(old('city') == 'Delhi' ? 'selected' : ''); ?>>Delhi</option>
                    <option value="Delhi NCR" <?php echo e(old('city') == 'Delhi NCR' ? 'selected' : ''); ?>>Delhi NCR</option>
                    <option value="Hyderabad" <?php echo e(old('city') == 'Hyderabad' ? 'selected' : ''); ?>>Hyderabad</option>
                    <option value="Indore" <?php echo e(old('city') == 'Indore' ? 'selected' : ''); ?>>Indore</option>
                    <option value="Kochi" <?php echo e(old('city') == 'Kochi' ? 'selected' : ''); ?>>Kochi</option>
                    <option value="Mumbai" <?php echo e(old('city') == 'Mumbai' ? 'selected' : ''); ?>>Mumbai</option>
                    <option value="Mysore" <?php echo e(old('city') == 'Mysore' ? 'selected' : ''); ?>>Mysore</option>
                    <option value="Noida" <?php echo e(old('city') == 'Noida' ? 'selected' : ''); ?>>Noida</option>
                    <option value="Pune" <?php echo e(old('city') == 'Pune' ? 'selected' : ''); ?>>Pune</option>
                    <option value="Trivandrum" <?php echo e(old('city') == 'Trivandrum' ? 'selected' : ''); ?>>Trivandrum</option>
                    <option value="Vizag" <?php echo e(old('city') == 'Vizag' ? 'selected' : ''); ?>>Vizag</option>
                </select>
            </div>
        </div>

        <br>
        <div class="form-check">
            <input type="checkbox" class="form-check-input" id="proceed" name="proceed" required>
            <label class="form-check-label" for="proceed">By submitting, you agree to the <a href="<?php echo e(url('/info#privacy_policy')); ?>" style="text-decoration: none; color: whitesmoke">Terms and Conditions</a> of Secure Credit & its representatives to contact you.</label>
        </div>
        
        <center><button type="submit" class="btn btn-primary">Submit</button></center>

    </form>

    <hr style="background-color:white;">

    <nav class="navbar navbar-expand navbar-light bg-light">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav menu mr-auto">
            <li class="nav-item">
              <a class="nav-link menu-btn" href="#about">Overview <span class="sr-only">(current)</span></a>
            </li>
            
          </ul>
        </div>
    </nav>

    <div class="menu-content about" style="color:black;">
        <div class="jumbotron">
            There are several type of business investments available in the market that can be considered as a business loan.<br><br>
            Here’s a list of some common types of Business Loan:<br><br>
            <ul>
                <li><b><a href="<?php echo e(url('/business_loan_form')); ?>" style="text-decoration: none; color: black">Loans for Self-employed Entrepreneurs: </a></b><br>
                Business loan are offered by various banks & financial institutions across the country are customized & customer centric with a minimum interest rate for Business or MSME loans starting from 14.99% and onwards.<br><br>
                <li><b><a href="<?php echo e(url('/invoice_discounting_form')); ?>" style="text-decoration: none; color: black">Invoice discounting: </a></b><br>
                Invoice discounting is probably the simplest form of invoice finance. As with all types of invoice finance, with invoice discounting you sell unpaid invoices to a lender and they give you a cash advance that’s a percentage of the invoice’s value. Once your customer has paid the invoice, the lender pays you the remaining balance minus their fee.<br><br>
                <li><b><a href="<?php echo e(url('/pos_based_loan_form')); ?>" style="text-decoration: none; color: black">POS/Card swiping machine based loan: </a></b><br>
                POS based loans are offered to business which accepts credit/ debit card payments or online sales. Avail loans against card swipes of up to 300% of your monthly sales via POS machines. These collateral free loans are disbursed within 3 to 7 days. Minimum monthly sales via POS machines or online sales should be more than ₹50,000.<br><br>
                <li><b><a href="<?php echo e(url('/lease_rental_discounting_form')); ?>" style="text-decoration: none; color: black">Lease rental discounting: </a></b><br>
                Lease Rental Discounting is a type of loans provided by financial institutions by using rental receipts as collateral. The financial institutions will examine long-term cash flow and provide the loan based on the exact amount. This loan is then payable by the rents promised.<br><br>
                <li><b><a href="<?php echo e(url('/invoice_discounting_form')); ?>" style="text-decoration: none; color: black">Working Capital Loan: </a></b><br>
                A working capital loan is a loan that is taken to finance a company's everyday operations. These loans are not used to buy long-term assets or investments and are, instead, used to provide the working capital that covers a company's short-term operational needs.<br><br>
            </ul>
        </div>
    </div>
    

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript">
        var $content = $('.menu-content');
    
        function showContent(type) {
          $content.hide().filter('.' + type).show();
        }
    
        $('.menu').on('click', '.menu-btn', function(e) {
          showContent(e.currentTarget.hash.slice(1));
          e.preventDefault();
        }); 
    
        // show 'about' content only on page load (if you want)
        showContent('about');
    </script>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/forms/lease_rental_discounting_form.blade.php ENDPATH**/ ?>