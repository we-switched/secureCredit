<?php $__env->startSection('title', 'Savings Account'); ?>

<?php $__env->startSection('content'); ?>

<div class="text-center"><h3 style="color: whitesmoke">Apply for Saving Account</h3></div>
<div class="container" style="margin-top: 20px">
    <form method="POST" action="<?php echo e(url('/savings_account_form')); ?>" style="color: whitesmoke">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="name" placeholder="Enter your name (as per PAN card)" name="name" value="<?php echo e(old('name')); ?>" required>
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="email">Email address</label>
            <input type="email" class="form-control custom-mine <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" placeholder="Enter your email address" name="email" value="<?php echo e(old('email')); ?>" required>
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="phone">Phone No.</label>
            <input type="tel" pattern="[6789][0-9]{9}" size="10" class="form-control custom-mine <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phone" placeholder="Enter your phone no." name="phone" value="<?php echo e(old('phone')); ?>" required>
            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label>City</label>
            <div class="input-group">
                <select class="custom-select custom-mine selectpicker form-control" name="city" required>
                    <option value="">Choose ...</option>
                    <option value="Ahmedabad" <?php echo e(old('city') == 'Ahmedabad' ? 'selected' : ''); ?>>Ahmedabad</option>
                    <option value="Bangalore" <?php echo e(old('city') == 'Bangalore' ? 'selected' : ''); ?>>Bangalore</option>
                    <option value="Chennai" <?php echo e(old('city') == 'Chennai' ? 'selected' : ''); ?>>Chennai</option>
                    <option value="Coimbatore" <?php echo e(old('city') == 'Coimbatore' ? 'selected' : ''); ?>>Coimbatore</option>
                    <option value="Delhi" <?php echo e(old('city') == 'Delhi' ? 'selected' : ''); ?>>Delhi</option>
                    <option value="Delhi NCR" <?php echo e(old('city') == 'Delhi NCR' ? 'selected' : ''); ?>>Delhi NCR</option>
                    <option value="Hyderabad" <?php echo e(old('city') == 'Hyderabad' ? 'selected' : ''); ?>>Hyderabad</option>
                    <option value="Indore" <?php echo e(old('city') == 'Indore' ? 'selected' : ''); ?>>Indore</option>
                    <option value="Kochi" <?php echo e(old('city') == 'Kochi' ? 'selected' : ''); ?>>Kochi</option>
                    <option value="Mumbai" <?php echo e(old('city') == 'Mumbai' ? 'selected' : ''); ?>>Mumbai</option>
                    <option value="Mysore" <?php echo e(old('city') == 'Mysore' ? 'selected' : ''); ?>>Mysore</option>
                    <option value="Noida" <?php echo e(old('city') == 'Noida' ? 'selected' : ''); ?>>Noida</option>
                    <option value="Pune" <?php echo e(old('city') == 'Pune' ? 'selected' : ''); ?>>Pune</option>
                    <option value="Trivandrum" <?php echo e(old('city') == 'Trivandrum' ? 'selected' : ''); ?>>Trivandrum</option>
                    <option value="Vizag" <?php echo e(old('city') == 'Vizag' ? 'selected' : ''); ?>>Vizag</option>
                </select>
            </div>
        </div>

        <br>
        <div class="form-check">
            <input type="checkbox" class="form-check-input" id="proceed" name="proceed" required>
            <label for="proceed"><small>By submitting, you agree to the <a href="<?php echo e(url('/info#privacy_policy')); ?>" target="blank" style="text-decoration: none; color: whitesmoke"><b>Terms and Conditions</b></a> of Secure Credit & its representatives to contact you.</small></label>
        </div>
        
        <center><button type="submit" class="btn btn-primary">Submit</button></center>

    </form>

    <hr style="background-color:white;">

    <nav class="navbar navbar-expand navbar-light bg-light">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav menu mr-auto">
            <li class="nav-item">
                <h4><a class="nav-link menu-btn" href="#about">Overview <span class="sr-only">(current)</span></a></h4>
            </li>
          </ul>
        </div>
    </nav>

    <div class="menu-content about" style="color:black;">
        <div class="jumbotron">
            Take advantage of exclusive instant savings account with no maintenance charges. Our partners exclusive savings account program offer automated daily returns on your regular savings account with up to 8% per annum*<br>
            Features & Benefits:<br>
            <ul>
                <li>Up to 8% per annum*returns on savings account.
                <li>Daily interest credit
                <li>No maintenance charges
                <li>Instant account opening
                <li>Lowest daily balance savings account
                <li>Digital savings app on-the-go
            </ul>
            Related products<br>
            <ul>
                <li><a href="<?php echo e(url('/savings_account_form')); ?>"><b>Current account</b></a> with 2% p.a.*returns
                <li><a href="<?php echo e(url('/savings_account_form')); ?>"><b>Fixed deposits</b></a> with 2% p.a.*returns
            </ul>
        </div>
    </div>
    <small style="color: whitesmoke">*(Subject to change as per financial institution’s discretion from time to time)</small>

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript">
        var $content = $('.menu-content');
    
        function showContent(type) {
          $content.hide().filter('.' + type).show();
        }
    
        $('.menu').on('click', '.menu-btn', function(e) {
          showContent(e.currentTarget.hash.slice(1));
          e.preventDefault();
        }); 
    
        // show 'about' content only on page load (if you want)
        showContent('about');
    </script>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/forms/savings_account_form.blade.php ENDPATH**/ ?>