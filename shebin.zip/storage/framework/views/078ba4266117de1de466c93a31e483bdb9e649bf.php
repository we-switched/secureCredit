<?php $__env->startSection('title', 'Home Loan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top: 20px">
    <form method="POST" action="<?php echo e(url('/home_loan_form/'.$loan->id)); ?>" style="color: whitesmoke">
    <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="name" placeholder="Enter your name (as per PAN card)" name="name" value="<?php echo e(old('name', $loan->name)); ?>" required>
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
        <div class="form-group">
            <label for="email">Email address</label>
            <input type="email" class="form-control custom-mine <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" placeholder="Enter your email address" name="email" value="<?php echo e(old('email', $loan->email)); ?>" required>
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
        <div class="form-group">
            <label for="phone">Phone No.</label>
            <input type="tel" pattern="[6789][0-9]{9}" size="10" class="form-control custom-mine <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phone" placeholder="Enter your phone no." name="phone" value="<?php echo e(old('phone', $loan->phone)); ?>" required>            
            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label>Is it a Top-Up Loan ?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="topup" value="No" id="topupno" <?php echo e(old('topup', $loan->topup) == "No" ? 'checked' : ''); ?> required>
                <label class="form-check-label" for="topupno">No</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="topup" value="Yes" id="topupyes" <?php echo e(old('topup', $loan->topup) == "Yes" ? 'checked' : ''); ?> required>
                <label class="form-check-label" for="topupyes">Yes</label>
            </div>
        </div>

        <div class="form-group">
            <label>Have you availed moratorium offered by RBI ?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="moratorium" value="No" id="moratoriumno" <?php echo e(old('moratorium', $loan->moratorium) == "No" ? 'checked' : ''); ?> required>
                <label class="form-check-label" for="moratoriumno">No</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="moratorium" value="Yes" id="moratoriumyes" <?php echo e(old('moratorium', $loan->moratorium) == "Yes" ? 'checked' : ''); ?> required>
                <label class="form-check-label" for="moratoriumyes">Yes</label>
            </div>
        </div>
        
        <?php if(auth()->user()->role === "Admin"): ?>
        <div class="form-group">
            <label>Telecaller</label>
            <select class="custom-select custom-mine" name="telecaller">
                <option value="">Choose ... </option>
                <?php $__currentLoopData = $telecallers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telecaller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($telecaller->name); ?>" <?php echo e(old('telecaller', $loan->telecaller) == $telecaller->name ? 'selected' : ''); ?>><?php echo e($telecaller->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php endif; ?>

        <div class="form-group">
            <label>Status</label>
            <select class="custom-select custom-mine" name="status" required>
                <option value="">Choose ...</option>
                <option value="Not Called" <?php echo e(old('status', $loan->status) == "Not Called" ? 'selected' : ''); ?>>Not Called</option>
                <option value="Not Doable" <?php echo e(old('status', $loan->status) == "Not Doable" ? 'selected' : ''); ?>>Not Doable</option>
                <option value="Not Eligible" <?php echo e(old('status', $loan->status) == "Not Eligible" ? 'selected' : ''); ?>>Not Eligible</option>
                <option value="Not Reachable" <?php echo e(old('status', $loan->status) == "Not Reachable" ? 'selected' : ''); ?>>Not Reachable</option>
                <option value="Not Interested" <?php echo e(old('status', $loan->status) == "Not Interested" ? 'selected' : ''); ?>>Not Interested</option>
                <option value="Wrong no." <?php echo e(old('status', $loan->status) == "Wrong no." ? 'selected' : ''); ?>>Wrong no.</option>
                <option value="Ringing" <?php echo e(old('status', $loan->status) == "Ringing" ? 'selected' : ''); ?>>Ringing</option>
                <option value="Follow Up" <?php echo e(old('status', $loan->status) == "Follow Up" ? 'selected' : ''); ?>>Follow Up</option>
                <option value="Meeting" <?php echo e(old('status', $loan->status) == "Meeting" ? 'selected' : ''); ?>>Meeting</option>
                <option value="DOC Pickup" <?php echo e(old('status', $loan->status) == "DOC Pickup" ? 'selected' : ''); ?>>DOC Pickup</option>
                <option value="Login" <?php echo e(old('status', $loan->status) == "Login" ? 'selected' : ''); ?>>Login</option>
                <option value="Rejected" <?php echo e(old('status', $loan->status) == "Rejected" ? 'selected' : ''); ?>>Rejected</option>
                <option value="Sanctioned" <?php echo e(old('status', $loan->status) == "Sanctioned" ? 'selected' : ''); ?>>Sanctioned</option>
                <option value="Disbursed" <?php echo e(old('status', $loan->status) == "Disbursed" ? 'selected' : ''); ?>>Disbursed</option>
                <option value="Repeated Lead" <?php echo e(old('status', $loan->status) == "Repeated Lead" ? 'selected' : ''); ?>>Repeated Lead</option>
            </select>
        </div>

        <div class="form-group">
            <label>Select City</label>
            <select class="custom-select custom-mine" name="city" required onchange="show_katha()">
                <option value="">Choose ...</option>
                <option value="Ahmedabad" <?php echo e(old('city', $loan->city) == "Ahmedabad" ? 'selected' : ''); ?>>Ahmedabad</option>
                <option value="Bangalore" id="bangalore" <?php echo e(old('city', $loan->city) == "Bangalore" ? 'selected' : ''); ?>>Bangalore</option>
                <option value="Chennai" <?php echo e(old('city', $loan->city) == "Chennai" ? 'selected' : ''); ?>>Chennai</option>
                <option value="Coimbatore" <?php echo e(old('city', $loan->city) == "Coimbatore" ? 'selected' : ''); ?>>Coimbatore</option>
                <option value="Delhi" <?php echo e(old('city', $loan->city) == "Delhi" ? 'selected' : ''); ?>>Delhi</option>
                <option value="Delhi NCR" <?php echo e(old('city', $loan->city) == "Delhi NCR" ? 'selected' : ''); ?>>Delhi NCR</option>
                <option value="Hyderabad" <?php echo e(old('city', $loan->city) == "Hyderabad" ? 'selected' : ''); ?>>Hyderabad</option>
                <option value="Indore" <?php echo e(old('city', $loan->city) == "Indore" ? 'selected' : ''); ?>>Indore</option>
                <option value="Kochi" <?php echo e(old('city', $loan->city) == "Kochi" ? 'selected' : ''); ?>>Kochi</option>
                <option value="Mumbai" <?php echo e(old('city', $loan->city) == "Mumbai" ? 'selected' : ''); ?>>Mumbai</option>
                <option value="Mysore" <?php echo e(old('city', $loan->city) == "Mysore" ? 'selected' : ''); ?>>Mysore</option>
                <option value="Noida" <?php echo e(old('city', $loan->city) == "Noida" ? 'selected' : ''); ?>>Noida</option>
                <option value="Pune" <?php echo e(old('city', $loan->city) == "Pune" ? 'selected' : ''); ?>>Pune</option>
                <option value="Trivandrum" <?php echo e(old('city', $loan->city) == "Trivandrum" ? 'selected' : ''); ?>>Trivandrum</option>
                <option value="Vizag" <?php echo e(old('city', $loan->city) == "Vizag" ? 'selected' : ''); ?>>Vizag</option>
            </select>
        </div>
            
        <div class="form-group">
            <label>Type of home loan</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="typeofhomeloan" value="Ready to move in house purchase" id="ready" <?php echo e(old('typeofhomeloan', $loan->typeofhomeloan) == "Ready to move in house purchase" ? 'checked' : ''); ?> required>
                <label class="form-check-label" for="ready">Ready to move in house purchase</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="typeofhomeloan" value="Flat" id="flat" <?php echo e(old('typeofhomeloan', $loan->typeofhomeloan) == "Flat" ? 'checked' : ''); ?> required>
                <label class="form-check-label" for="flat">Flat purchase</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="typeofhomeloan" value="Home construction" id="home" <?php echo e(old('typeofhomeloan', $loan->typeofhomeloan) == "Home construction" ? 'checked' : ''); ?> required>
                <label class="form-check-label" for="home">Home construction loan</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="typeofhomeloan" value="Plot purchase" id="plot" <?php echo e(old('typeofhomeloan', $loan->typeofhomeloan) == "Plot purchase" ? 'checked' : ''); ?> required>
                <label class="form-check-label" for="plot">Plot purchase loan</label>
            </div>
        </div>
        
        <div class="form-group">
            <label>Type of employment</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="employmenttype" value="Salaried" id="salaried" <?php echo e(old('employmenttype', $loan->employmenttype) == "Salaried" ? 'checked' : ''); ?> required onclick="check()">
                <label class="form-check-label" for="salaried">Salaried</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="employmenttype" value="Self Employed" id="selfemployed" <?php echo e(old('employmenttype', $loan->employmenttype) == "Self Employed" ? 'checked' : ''); ?> required onclick="check()">
                <label class="form-check-label" for="selfemployed">Self Employed</label>
            </div>
        </div>

        <div class="form-group" id="modeofsalary" style="display: none">
            <label for="id_modeofsalary">Mode of salary</label>
            <select class="custom-select custom-mine" name="modeofsalary" id="id_modeofsalary">
                <option value="">Choose ...</option>
                <optgroup label="Mode">
                    <option value="Cash" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Cash" ? 'selected' : ''); ?>>Cash</option>
                    <option value="Cheque" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Cheque" ? 'selected' : ''); ?>>Cheque</option>
                </optgroup>
                <optgroup label="Bank">
                    <option value="HDFC Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "HDFC Bank" ? 'selected' : ''); ?>>HDFC Bank</option>
                    <option value="ICICI Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "ICICI Bank" ? 'selected' : ''); ?>>ICICI Bank</option>
                    <option value="Kotak Mahindra" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Kotak Mahindra" ? 'selected' : ''); ?>>Kotak Mahindra</option>
                    <option value="IndusInd Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "IndusInd Bank" ? 'selected' : ''); ?>>IndusInd Bank</option>
                    <option value="RBL Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "RBL Bank" ? 'selected' : ''); ?>>RBL Bank</option>
                    <option value="Federal Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Federal Bank" ? 'selected' : ''); ?>>Federal Bank</option>
                    <option value="South Indian Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "South Indian Bank" ? 'selected' : ''); ?>>South Indian Bank</option>
                    <option value="Axis Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Axis Bank" ? 'selected' : ''); ?>>Axis Bank</option>
                    <option value="SBI" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "SBI" ? 'selected' : ''); ?>>SBI</option>
                    <option value="Canara Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Canara Bank" ? 'selected' : ''); ?>>Canara Bank</option>
                    <option value="Syndicate Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Syndicate Bank" ? 'selected' : ''); ?>>Syndicate Bank</option>
                    <option value="PNB" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "PNB" ? 'selected' : ''); ?>>PNB</option>
                    <option value="Union Bank of India" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Union Bank of India" ? 'selected' : ''); ?>>Union Bank of India</option>
                    <option value="IDFC First Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "IDFC First Bank" ? 'selected' : ''); ?>>IDFC First Bank</option>
                    <option value="Karnataka Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Karnataka Bank" ? 'selected' : ''); ?>>Karnataka Bank</option>
                    <option value="Karur Vysya Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Karur Vysya Bank" ? 'selected' : ''); ?>>Karur Vysya Bank</option>
                    <option value="Citi Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Citi Bank" ? 'selected' : ''); ?>>Citi Bank</option>
                    <option value="Standard Chartered" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Standard Chartered" ? 'selected' : ''); ?>>Standard Chartered</option>
                    <option value="Dena Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Dena Bank" ? 'selected' : ''); ?>>Dena Bank</option>
                    <option value="Yes Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Yes Bank" ? 'selected' : ''); ?>>Yes Bank</option>
                    <option value="DBS Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "DBS Bank" ? 'selected' : ''); ?>>DBS Bank</option>
                    <option value="HSBC Banking Corp." <?php echo e(old('modeofsalary', $loan->modeofsalary) == "HSBC Banking Corp." ? 'selected' : ''); ?>>HSBC Banking Corp.</option>
                    <option value="Bank of Baroda" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Bank of Baroda" ? 'selected' : ''); ?>>Bank of Baroda</option>
                    <option value="Indian Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Indian Bank" ? 'selected' : ''); ?>>Indian Bank</option>
                </optgroup>
            </select>
        </div>
                
        <div class="form-group" id="netsalary" style="display: none">
            <label for="netsalary">Net monthly salary</label>
            <input type="number" min="0" id="id_netsalary" class="form-control custom-mine <?php if ($errors->has('netsalary')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netsalary'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Enter net take home salary" name="netsalary" value="<?php echo e(old('netsalary', $loan->netsalary)); ?>">
            <?php if ($errors->has('netsalary')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netsalary'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group" id="profit" style="display: none">
            <label for="profit">Net profit</label>
            <input type="number" id="id_profit" min="0" class="form-control custom-mine <?php if ($errors->has('profit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('profit'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Enter net proft as per last year ITR" name="profit" value="<?php echo e(old('profit', $loan->profit)); ?>">
            <?php if ($errors->has('profit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('profit'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
        <div class="form-group" id="turnover" style="display: none">
            <label for="turnover">Gross turnover</label>
            <input type="number" min="0" id="id_turnover" class="form-control custom-mine <?php if ($errors->has('turnover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('turnover'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Enter gross turnover as per last year ITR" name="turnover" value="<?php echo e(old('turnover', $loan->turnover)); ?>">
            <?php if ($errors->has('turnover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('turnover'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
        <div class="form-group">
            <label for="loanamount">Loan amount</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('loanamount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('loanamount'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="loanamount" placeholder="Enter required loan amount" name="loanamount" value="<?php echo e(old('loanamount', $loan->loanamount)); ?>" required>
            <?php if ($errors->has('loanamount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('loanamount'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
            
        <div class="form-group">
            <label for="marketvalue">Market Value of the property</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('marketvalue')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('marketvalue'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="marketvalue" placeholder="Enter the property's market value" name="marketvalue" value="<?php echo e(old('marketvalue', $loan->marketvalue)); ?>" required>
            <?php if ($errors->has('marketvalue')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('marketvalue'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    
        <div class="form-group">
            <label for="governmentvalue">Govt. Value of the property</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('governmentvalue')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('governmentvalue'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="governmentvalue" placeholder="Enter the property's govt. value" name="governmentvalue" value="<?php echo e(old('governmentvalue', $loan->governmentvalue)); ?>" required>
            <?php if ($errors->has('governmentvalue')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('governmentvalue'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group" id="katha" style="display: none">
            <label>Katha of property</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="katha" value="A" id="kathaA" <?php echo e(old('katha', $loan->katha) == "A" ? 'checked' : ''); ?>>
                <label class="form-check-label" for="kathaA">A Katha</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="katha" value="B" id="kathaB" <?php echo e(old('katha', $loan->katha) == "B" ? 'checked' : ''); ?>>
                <label class="form-check-label" for="kathaB">B Katha</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="katha" value="E" id="kathaE" <?php echo e(old('katha', $loan->katha) == "E" ? 'checked' : ''); ?>>
                <label class="form-check-label" for="kathaE">E Katha</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="katha" value="Other" id="kathaOther" <?php echo e(old('katha', $loan->katha) == "Other" ? 'checked' : ''); ?>>
                <label class="form-check-label" for="kathaOther">Other</label>
            </div>
        </div>

        <center><button type="submit" class="btn btn-primary">Submit</button></center>

    </form>

</div>

<script>
    if(document.getElementById("salaried").checked) {
        document.getElementById("modeofsalary").style.display = "block";
        document.getElementById("netsalary").style.display = "block";
        document.getElementById("id_modeofsalary").setAttribute("required", "true");
        document.getElementById("id_netsalary").setAttribute("required", "true");
        document.getElementById("profit").style.display = "none";
        document.getElementById("turnover").style.display = "none";
        document.getElementById("id_profit").removeAttribute("required");
        document.getElementById("id_turnover").removeAttribute("required");
    }
    else if(document.getElementById("selfemployed").checked) {
        document.getElementById("modeofsalary").style.display = "none";
        document.getElementById("netsalary").style.display = "none";
        document.getElementById("id_modeofsalary").removeAttribute("required");
        document.getElementById("id_netsalary").removeAttribute("required");
        document.getElementById("profit").style.display = "block";
        document.getElementById("turnover").style.display = "block";
        document.getElementById("id_profit").setAttribute("required", "true");
        document.getElementById("id_turnover").setAttribute("required", "true");
    }

    if(document.getElementById("bangalore").selected) {
        document.getElementById("katha").style.display = "block";
        document.getElementById("kathaA").setAttribute("required", "true");
    }
    else {
        document.getElementById("katha").style.display = "none";
        document.getElementById("kathaA").removeAttribute("required");
    }

</script>

<script>
    function check() {
        if(document.getElementById("salaried").checked) {
            document.getElementById("modeofsalary").style.display = "block";
            document.getElementById("netsalary").style.display = "block";
            document.getElementById("id_modeofsalary").setAttribute("required", "true");
            document.getElementById("id_netsalary").setAttribute("required", "true");
            document.getElementById("profit").style.display = "none";
            document.getElementById("turnover").style.display = "none";
            document.getElementById("id_profit").removeAttribute("required");
            document.getElementById("id_turnover").removeAttribute("required");
        }
        else if(document.getElementById("selfemployed").checked) {
            document.getElementById("modeofsalary").style.display = "none";
            document.getElementById("netsalary").style.display = "none";
            document.getElementById("id_modeofsalary").removeAttribute("required");
            document.getElementById("id_netsalary").removeAttribute("required");
            document.getElementById("profit").style.display = "block";
            document.getElementById("turnover").style.display = "block";
            document.getElementById("id_profit").setAttribute("required", "true");
            document.getElementById("id_turnover").setAttribute("required", "true");
        }
    }

    function show_katha() {
        if(document.getElementById("bangalore").selected) {
            document.getElementById("katha").style.display = "block";
            document.getElementById("kathaA").setAttribute("required", "true");
        }
        else {
            document.getElementById("katha").style.display = "none";
            document.getElementById("kathaA").removeAttribute("required");
        }
    }
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/edit/home_loan_form.blade.php ENDPATH**/ ?>