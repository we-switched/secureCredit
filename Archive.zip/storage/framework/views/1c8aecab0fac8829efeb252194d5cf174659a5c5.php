

<?php $__env->startSection('title', 'Secure Credit'); ?>

<?php $__env->startSection('content'); ?>

<h3 class="text-center" style="color: white">Home Loan Applicants <a href="<?php echo e(url('/home_loan_export')); ?>" style="text-decoration: none; color: whitesmoke"><i class="fa fa-download" aria-hidden="true"></i></a></h3>

<div class="container">
    <?php if($applicants->count() > 0): ?>
    <div class="table-responsive">
        <table class="table table-bordered table-dark" style="margin: 30px;">
            <thead>
                <tr>
                    <?php if(auth()->user()->role == "Admin" || auth()->user()->role == "Telecaller"): ?>
                    <th scope="col">Action</th>
                    <?php endif; ?>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone No.</th>
                    <th scope="col">Top-Up</th>
                    <th scope="col">Moratorium availed</th>
                    <th scope="col">Agent</th>
                    <th scope="col">Telecaller</th>
                    <th scope="col">Status</th>
                    <th scope="col">City</th>
                    <th scope="col">Employment Type</th>
                    <th scope="col">Type of Home Loan</th>
                    <th scope="col">Mode of Salary</th>
                    <th scope="col">Net Salary</th>
                    <th scope="col">Profit</th>
                    <th scope="col">Turnover</th>
                    <th scope="col">Loan Amount</th>
                    <th scope="col">Market Value</th>
                    <th scope="col">Government Value</th>
                    <th scope="col">Katha</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if(auth()->user()->role == "Admin" || auth()->user()->role == "Telecaller"): ?>
                        <td>
                            <a href="<?php echo e(url('/home_loan_form/'.$person->id)); ?>"><i class="fa fa-pencil-square-o float-left" style="color: whitesmoke; size: 10px; margin-top:2px;" aria-hidden="true"></i></a>
                            <form method="POST" action="<?php echo e(url('/home_loan/'.$person->id)); ?>"> <?php echo method_field('DELETE'); ?> <?php echo csrf_field(); ?> <button type="submit" style="background:none; margin-left:2px;"><i class="fa fa-trash float-right" style="color: whitesmoke; size:10px;" aria-hidden="true"></i></button></form>
                        </td>
                        <?php endif; ?>
                        <td><?php echo e($person->name); ?></td>
                        <td><a href="mailto:<?php echo e($person->email); ?>"><?php echo e($person->email); ?></a></td>
                        <td><?php echo e($person->phone); ?></td>
                        <td><?php echo e($person->topup); ?></td>
                        <td><?php echo e($person->moratorium); ?></td>
                        <td><?php echo e($person->agent); ?></td>
                        <td><?php echo e($person->telecaller); ?></td>
                        <td><?php echo e($person->status); ?></td>
                        <td><?php echo e($person->city); ?></td>
                        <td><?php echo e($person->employmenttype); ?></td>
                        <td><?php echo e($person->typeofhomeloan); ?></td>
                        <td><?php echo e($person->modeofsalary); ?></td>
                        <td><?php echo e($person->netsalary); ?></td>
                        <td><?php echo e($person->profit); ?></td>
                        <td><?php echo e($person->turnover); ?></td>
                        <td><?php echo e($person->loanamount); ?></td>
                        <td><?php echo e($person->marketvalue); ?></td>
                        <td><?php echo e($person->governmentvalue); ?></td>
                        <td><?php echo e($person->katha); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
        <h3 class="text-center" style="color: white">No Applications yet!</h3>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u181465707/domains/securecredit.in/securecredit/resources/views/details/home_loan.blade.php ENDPATH**/ ?>