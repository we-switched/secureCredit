<?php $__env->startSection('title', 'Secure Credit'); ?>

<?php $__env->startSection('content'); ?>

<h3 class="text-center" style="color: white">Current Account Applicants  <a href="<?php echo e(url('/current_account_export')); ?>" style="text-decoration: none; color: whitesmoke"><i class="fa fa-download" aria-hidden="true"></i></a></h3>

<div class="container">
    <?php if($applicants->count() > 0): ?>
    <div class="table-responsive">
        <table class="table table-bordered table-dark" style="margin: 30px;">
            <thead>
                <tr>
                    <th scope="col">Action</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone No.</th>
                    <th scope="col">Agent</th>
                    <th scope="col">Telecaller</th>
                    <th scope="col">Status</th>
                    <th scope="col">City</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <i class="fa fa-edit float-left" style="color: whitesmoke"></i>
                            <form method="POST" action="<?php echo e(url('/CurrentAccount/details/'.$person->id)); ?>"><?php echo csrf_field(); ?><button type="submit"><i class="fa fa-trash float-right"></i></button></form>
                        </td>
                        <td><?php echo e($person->name); ?></td>
                        <td><?php echo e($person->email); ?></td>
                        <td><?php echo e($person->phone); ?></td>
                        <td><?php echo e($person->agent); ?></td>
                        <td><?php echo e($person->telecaller); ?></td>
                        <td>        
                            <select class="custom-select custom-mine" name="status" required>
                                <option value="Not Called">Not Called</option>
                                <option value="Not Doable">Not Doable</option>
                                <option value="Not Eligible">Not Eligible</option>
                                <option value="Not Reachable">Not Reachable</option>
                                <option value="Not Interested">Not Interested</option>
                                <option value="Wrong no.">Wrong no.</option>
                                <option value="Ringing">Ringing</option>
                                <option value="Follow Up">Follow Up</option>
                                <option value="Meeting">Meeting</option>
                                <option value="DOC Pickup">DOC Pickup</option>
                                <option value="Login">Login</option>
                                <option value="Rejected">Rejected</option>
                                <option value="Sanctioned">Sanctioned</option>
                                <option value="Disbursed">Disbursed</option>
                                <option value="Repeated Lead">Repeated Lead</option>
                            </select>
                        </td>
                        <td><?php echo e($person->city); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
        <h3 class="text-center" style="color: white">No Applications yet!</h3>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/details/current_account.blade.php ENDPATH**/ ?>