<?php $__env->startSection('title', 'Credit Card Balance Transfer'); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top: 20px">
    <form method="POST" action="<?php echo e(url('/credit_card_balance_transfer_form/'.$loan->id)); ?>" style="color: whitesmoke">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="name" placeholder="Enter your name (as per PAN card)" name="name" value="<?php echo e(old('name', $loan->name)); ?>" required>
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="email">Email address</label>
            <input type="email" class="form-control custom-mine <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" placeholder="Enter your email address" name="email" value="<?php echo e(old('email', $loan->email)); ?>" required>
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="phone">Phone No.</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phone" placeholder="Enter your phone no." name="phone" value="<?php echo e(old('phone', $loan->phone)); ?>" required>
            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <?php if(auth()->user()->role === "Admin"): ?>
        <p>Telecaller</p>
        <select class="custom-select custom-mine" name="telecaller">
            <option value="">Choose ... </option>
            <?php $__currentLoopData = $telecallers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telecaller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($telecaller->name); ?>" <?php echo e((old('telecaller', $loan->telecaller) == $telecaller->name) ? 'selected' : ''); ?>><?php echo e($telecaller->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <?php endif; ?>

        <p>Status</p>
        <select class="custom-select custom-mine" name="status" required>
            <option value="">Choose ...</option>
            <option value="Not Called" <?php echo e(old('status', $loan->status) == "Not Called" ? 'selected' : ''); ?>>Not Called</option>
            <option value="Not Doable" <?php echo e(old('status', $loan->status) == "Not Doable" ? 'selected' : ''); ?>>Not Doable</option>
            <option value="Not Eligible" <?php echo e(old('status', $loan->status) == "Not Eligible" ? 'selected' : ''); ?>>Not Eligible</option>
            <option value="Not Reachable" <?php echo e(old('status', $loan->status) == "Not Reachable" ? 'selected' : ''); ?>>Not Reachable</option>
            <option value="Not Interested" <?php echo e(old('status', $loan->status) == "Not Interested" ? 'selected' : ''); ?>>Not Interested</option>
            <option value="Wrong no." <?php echo e(old('status', $loan->status) == "Wrong no." ? 'selected' : ''); ?>>Wrong no.</option>
            <option value="Ringing" <?php echo e(old('status', $loan->status) == "Ringing" ? 'selected' : ''); ?>>Ringing</option>
            <option value="Follow Up" <?php echo e(old('status', $loan->status) == "Follow Up" ? 'selected' : ''); ?>>Follow Up</option>
            <option value="Meeting" <?php echo e(old('status', $loan->status) == "Meeting" ? 'selected' : ''); ?>>Meeting</option>
            <option value="DOC Pickup" <?php echo e(old('status', $loan->status) == "DOC Pickup" ? 'selected' : ''); ?>>DOC Pickup</option>
            <option value="Login" <?php echo e(old('status', $loan->status) == "Login" ? 'selected' : ''); ?>>Login</option>
            <option value="Rejected" <?php echo e(old('status', $loan->status) == "Rejected" ? 'selected' : ''); ?>>Rejected</option>
            <option value="Sanctioned" <?php echo e(old('status', $loan->status) == "Sanctioned" ? 'selected' : ''); ?>>Sanctioned</option>
            <option value="Disbursed" <?php echo e(old('status', $loan->status) == "Disbursed" ? 'selected' : ''); ?>>Disbursed</option>
            <option value="Repeated Lead" <?php echo e(old('status', $loan->status) == "Repeated Lead" ? 'selected' : ''); ?>>Repeated Lead</option>
        </select><br><br>

        <p>Select City</p>
        <select class="custom-select custom-mine" name="city" required>
            <option value="">Choose ...</option>
            <option value="Ahmedabad" <?php echo e(old('city', $loan->city) == "Ahmedabad" ? 'selected' : ''); ?>>Ahmedabad</option>
            <option value="Bangalore" <?php echo e(old('city', $loan->city) == "Bangalore" ? 'selected' : ''); ?>>Bangalore</option>
            <option value="Chennai" <?php echo e(old('city', $loan->city) == "Chennai" ? 'selected' : ''); ?>>Chennai</option>
            <option value="Coimbatore" <?php echo e(old('city', $loan->city) == "Coimbatore" ? 'selected' : ''); ?>>Coimbatore</option>
            <option value="Delhi" <?php echo e(old('city', $loan->city) == "Delhi" ? 'selected' : ''); ?>>Delhi</option>
            <option value="Delhi NCR" <?php echo e(old('city', $loan->city) == "Delhi NCR" ? 'selected' : ''); ?>>Delhi NCR</option>
            <option value="Hyderabad" <?php echo e(old('city', $loan->city) == "Hyderabad" ? 'selected' : ''); ?>>Hyderabad</option>
            <option value="Indore" <?php echo e(old('city', $loan->city) == "Indore" ? 'selected' : ''); ?>>Indore</option>
            <option value="Kochi" <?php echo e(old('city', $loan->city) == "Kochi" ? 'selected' : ''); ?>>Kochi</option>
            <option value="Mumbai" <?php echo e(old('city', $loan->city) == "Mumbai" ? 'selected' : ''); ?>>Mumbai</option>
            <option value="Mysore" <?php echo e(old('city', $loan->city) == "Mysore" ? 'selected' : ''); ?>>Mysore</option>
            <option value="Noida" <?php echo e(old('city', $loan->city) == "Noida" ? 'selected' : ''); ?>>Noida</option>
            <option value="Pune" <?php echo e(old('city', $loan->city) == "Pune" ? 'selected' : ''); ?>>Pune</option>
            <option value="Trivandrum" <?php echo e(old('city', $loan->city) == "Trivandrum" ? 'selected' : ''); ?>>Trivandrum</option>
            <option value="Vizag" <?php echo e(old('city', $loan->city) == "Vizag" ? 'selected' : ''); ?>>Vizag</option>
        </select><br><br>

        <p>Have you availed moratorium offered by RBI ?</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="moratorium" value="No" id="moratoriumno" <?php echo e(old('moratorium', $loan->moratorium) == "No" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="moratoriumno">No</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="moratorium" value="Yes" id="moratoriumyes" <?php echo e(old('moratorium', $loan->moratorium) == "Yes" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="moratoriumyes">Yes</label>
        </div><br>
                
        <div class="form-group">
            <p><b>Type of employment</b></p>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="employmenttype" value="Salaried" id="salaried" <?php echo e(old('employmenttype', $loan->employmenttype) == "Salaried" ? 'checked' : ''); ?> required onclick="check()">
                <label class="form-check-label" for="salaried">Salaried</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="employmenttype" value="Self Employed" id="selfemployed" <?php echo e(old('employmenttype', $loan->employmenttype) == "Self Employed" ? 'checked' : ''); ?> required onclick="check()">
                <label class="form-check-label" for="selfemployed">Self Employed</label>
            </div><br>
        </div>
        
        <div class="form-group" id="modeofsalary" style="display: none">
            <label>Salary mode of salary</label>
            <div class="input-group">
                <select class="custom-select custom-mine selectpicker form-control" name="modeofsalary">
                    <option value="">Choose ...</option>
                    <optgroup label="Mode">
                        <option value="Cash" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Cash" ? 'selected' : ''); ?>>Cash</option>
                        <option value="Cheque" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Cheque" ? 'selected' : ''); ?>>Cheque</option>
                    </optgroup>
                    <optgroup label="Bank">
                        <option value="HDFC Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "HDFC Bank" ? 'selected' : ''); ?>>HDFC Bank</option>
                        <option value="ICICI Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "ICICI Bank" ? 'selected' : ''); ?>>ICICI Bank</option>
                        <option value="Kotak Mahindra" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Kotak Mahindra" ? 'selected' : ''); ?>>Kotak Mahindra</option>
                        <option value="IndusInd Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "IndusInd Bank" ? 'selected' : ''); ?>>IndusInd Bank</option>
                        <option value="RBL Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "RBL Bank" ? 'selected' : ''); ?>>RBL Bank</option>
                        <option value="Federal Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Federal Bank" ? 'selected' : ''); ?>>Federal Bank</option>
                        <option value="South Indian Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "South Indian Bank" ? 'selected' : ''); ?>>South Indian Bank</option>
                        <option value="Axis Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Axis Bank" ? 'selected' : ''); ?>>Axis Bank</option>
                        <option value="SBI" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "SBI" ? 'selected' : ''); ?>>SBI</option>
                        <option value="Canara Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Canara Bank" ? 'selected' : ''); ?>>Canara Bank</option>
                        <option value="Syndicate Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Syndicate Bank" ? 'selected' : ''); ?>>Syndicate Bank</option>
                        <option value="PNB" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "PNB" ? 'selected' : ''); ?>>PNB</option>
                        <option value="Union Bank of India" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Union Bank of India" ? 'selected' : ''); ?>>Union Bank of India</option>
                        <option value="IDFC First Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "IDFC First Bank" ? 'selected' : ''); ?>>IDFC First Bank</option>
                        <option value="Karnataka Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Karnataka Bank" ? 'selected' : ''); ?>>Karnataka Bank</option>
                        <option value="Karur Vysya Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Karur Vysya Bank" ? 'selected' : ''); ?>>Karur Vysya Bank</option>
                        <option value="Citi Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Citi Bank" ? 'selected' : ''); ?>>Citi Bank</option>
                        <option value="Standard Chartered" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Standard Chartered" ? 'selected' : ''); ?>>Standard Chartered</option>
                        <option value="Dena Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Dena Bank" ? 'selected' : ''); ?>>Dena Bank</option>
                        <option value="Yes Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Yes Bank" ? 'selected' : ''); ?>>Yes Bank</option>
                        <option value="DBS Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "DBS Bank" ? 'selected' : ''); ?>>DBS Bank</option>
                        <option value="HSBC Banking Corp." <?php echo e(old('modeofsalary', $loan->modeofsalary) == "HSBC Banking Corp." ? 'selected' : ''); ?>>HSBC Banking Corp.</option>
                        <option value="Bank of Baroda" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Bank of Baroda" ? 'selected' : ''); ?>>Bank of Baroda</option>
                        <option value="Indian Bank" <?php echo e(old('modeofsalary', $loan->modeofsalary) == "Indian Bank" ? 'selected' : ''); ?>>Indian Bank</option>
                    </optgroup>
                </select>
            </div>
        </div>

        <div class="form-group" id="netsalary" style="display: none">
            <label for="netsalary">Net monthly salary</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('netsalary')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netsalary'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Enter net take home salary" name="netsalary" value="<?php echo e(old('netsalary', $loan->netsalary)); ?>">
            <?php if ($errors->has('netsalary')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netsalary'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group" id="profit" style="display: none">
            <label for="profit">Net annual profit</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('profit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('profit'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Enter net take home proft" name="profit" value="<?php echo e(old('profit', $loan->profit)); ?>">
            <?php if ($errors->has('profit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('profit'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
        <div class="form-group" id="turnover" style="display: none">
            <label for="turnover">Net annual turnover</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('turnover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('turnover'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Enter net turnover" name="turnover" value="<?php echo e(old('turnover', $loan->turnover)); ?>">
            <?php if ($errors->has('turnover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('turnover'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
        <div class="form-group">
            <label for="noofcards">No. of cards</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('noofcards')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('noofcards'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="noofcards" placeholder="Enter total no. of cards owned by you" name="noofcards" value="<?php echo e(old('noofcards', $loan->noofcards)); ?>" required>
            <?php if ($errors->has('noofcards')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('noofcards'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="totalcreditlimit">Total Credit Limit on all cards</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('totalcreditlimit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('totalcreditlimit'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="totalcreditlimit" placeholder="Enter total credit limit on all cards" name="totalcreditlimit" value="<?php echo e(old('totalcreditlimit', $loan->totalcreditlimit)); ?>" required>
            <?php if ($errors->has('totalcreditlimit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('totalcreditlimit'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="currentoutstanding">Current Outstanding in all cards</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('currentoutstanding')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('currentoutstanding'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="currentoutstanding" placeholder="Enter current outstanding in all cards" name="currentoutstanding" value="<?php echo e(old('currentoutstanding', $loan->currentoutstanding)); ?>" required>
            <?php if ($errors->has('currentoutstanding')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('currentoutstanding'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="loanamount">Loan amount</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('loanamount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('loanamount'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="loanamount" placeholder="Enter required loan amount" name="loanamount" value="<?php echo e(old('loanamount', $loan->loanamount)); ?>" required>
            <?php if ($errors->has('loanamount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('loanamount'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <p>Any delay in payment in last three months</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="delayinpayment" id="delayinpaymentyes" value="Yes" <?php echo e(old('delayinpayment', $loan->delayinpayment) == "Yes" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="delayinpaymentyes">Yes</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="delayinpayment" id="delayinpaymentno" value="No" <?php echo e(old('delayinpayment', $loan->delayinpayment) == "No" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="delayinpaymentno">No</label>
        </div><br>

        <center><button type="submit" class="btn btn-primary">Submit</button></center>

    </form>

    <script>
        if(document.getElementById("salaried").checked) {
            document.getElementById("modeofsalary").style.display = "block";
            document.getElementById("netsalary").style.display = "block";
            document.getElementById("id_modeofsalary").setAttribute("required", "true");
            document.getElementById("id_netsalary").setAttribute("required", "true");
            document.getElementById("profit").style.display = "none";
            document.getElementById("turnover").style.display = "none";
            document.getElementById("id_profit").removeAttribute("required");
            document.getElementById("id_turnover").removeAttribute("required");
        }
        else if(document.getElementById("selfemployed").checked) {
            document.getElementById("modeofsalary").style.display = "none";
            document.getElementById("netsalary").style.display = "none";
            document.getElementById("id_modeofsalary").removeAttribute("required");
            document.getElementById("id_netsalary").removeAttribute("required");
            document.getElementById("profit").style.display = "block";
            document.getElementById("turnover").style.display = "block";
            document.getElementById("id_profit").setAttribute("required", "true");
            document.getElementById("id_turnover").setAttribute("required", "true");
        }
    </script>
    
    <script>
        function check() {
            if(document.getElementById("salaried").checked) {
                document.getElementById("modeofsalary").style.display = "block";
                document.getElementById("netsalary").style.display = "block";
                document.getElementById("modeofsalary").setAttribute("required", "true");
                document.getElementById("netsalary").setAttribute("required", "true");
                document.getElementById("profit").style.display = "none";
                document.getElementById("turnover").style.display = "none";
                document.getElementById("profit").removeAttribute("required");
                document.getElementById("turnover").removeAttribute("required");
            }
            else if(document.getElementById("selfemployed").checked) {
                document.getElementById("modeofsalary").style.display = "none";
                document.getElementById("netsalary").style.display = "none";
                document.getElementById("modeofsalary").removeAttribute("required");
                document.getElementById("netsalary").removeAttribute("required");
                document.getElementById("profit").style.display = "block";
                document.getElementById("turnover").style.display = "block";
                document.getElementById("profit").setAttribute("required", "true");
                document.getElementById("turnover").setAttribute("required", "true");
            }
        }
    </script>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/edit/credit_card_balance_transfer_form.blade.php ENDPATH**/ ?>