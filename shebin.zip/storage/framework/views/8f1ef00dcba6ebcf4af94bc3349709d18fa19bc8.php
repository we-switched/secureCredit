<?php $__env->startComponent('mail::message'); ?>

Service : <?php echo e($service); ?>

Name : **<?php echo e($name); ?>**  
Email address : <?php echo e($email); ?>  
Phone : <?php echo e($phone); ?>  

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/common/notification.blade.php ENDPATH**/ ?>