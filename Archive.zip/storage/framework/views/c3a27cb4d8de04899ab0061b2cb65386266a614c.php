

<?php $__env->startSection('title', 'Business Loan'); ?>

<?php $__env->startSection('content'); ?>

<div class="text-center"><h3 style="color: whitesmoke">Apply for Business Loan</h3></div>
<div class="container" style="margin-top: 2.5em">
    <form class="well form-horizontal" method="POST" action="<?php echo e(url('/business_loan_form')); ?>" style="color: whitesmoke">
    <?php echo csrf_field(); ?>
    
    <div class="row">
        <div class="col-md-6">
            
            <div class="form-group">
                <label for="name" class="col-md-4 control-label">Name</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="name" placeholder="Enter your name (as per PAN card)" name="name" value="<?php echo e(old('name')); ?>" required></div>
                </div>
                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            
            <div class="form-group">
                <label for="email" class="col-md-4 control-label">Email address</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group"><input type="email" class="form-control custom-mine <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" placeholder="Enter your email address" name="email" value="<?php echo e(old('email')); ?>" required></div>
                </div> 
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            
            <div class="form-group">
                <label for="phone" class="col-md-4 control-label">Phone No.</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group"><input type="tel" pattern="[6789][0-9]{9}" size="10" class="form-control custom-mine <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phone" placeholder="Enter your phone no." name="phone" value="<?php echo e(old('phone')); ?>" required></div>
                </div>
                <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
                <label>Is it a Top-Up Loan ?</label>
                <div class="form-check form-check-inline">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="topup" value="No" <?php echo e(old('topup') == "No" ? 'checked' : ''); ?> required>
                        <label class="col-md-2 control-label" for="topupno">No</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="topup" value="Yes" <?php echo e(old('topup') == "Yes" ? 'checked' : ''); ?> required>
                        <label class="col-md-2 control-label" for="topupyes">Yes</label>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label>Have you availed moratorium offered by RBI ?</label>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="moratorium" value="No" id="moratoriumno" <?php echo e(old('moratorium') == "No" ? 'checked' : ''); ?> required>
                    <label class="col-md-2 control-label" for="moratoriumno">No</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="moratorium" value="Yes" id="moratoriumyes" <?php echo e(old('moratorium') == "Yes" ? 'checked' : ''); ?> required>
                    <label class="col-md-2 control-label" for="moratoriumyes">Yes</label>
                </div>
            </div>
        
            <div class="form-group">
                <label class="col-md-4 control-label">City</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group">
                        <select class="custom-select custom-mine selectpicker form-control" name="city" required>
                            <option value="">Choose ...</option>
                            <option value="Ahmedabad" <?php echo e(old('city') == 'Ahmedabad' ? 'selected' : ''); ?>>Ahmedabad</option>
                            <option value="Bangalore" <?php echo e(old('city') == 'Bangalore' ? 'selected' : ''); ?>>Bangalore</option>
                            <option value="Chennai" <?php echo e(old('city') == 'Chennai' ? 'selected' : ''); ?>>Chennai</option>
                            <option value="Coimbatore" <?php echo e(old('city') == 'Coimbatore' ? 'selected' : ''); ?>>Coimbatore</option>
                            <option value="Delhi" <?php echo e(old('city') == 'Delhi' ? 'selected' : ''); ?>>Delhi</option>
                            <option value="Delhi NCR" <?php echo e(old('city') == 'Delhi NCR' ? 'selected' : ''); ?>>Delhi NCR</option>
                            <option value="Hyderabad" <?php echo e(old('city') == 'Hyderabad' ? 'selected' : ''); ?>>Hyderabad</option>
                            <option value="Indore" <?php echo e(old('city') == 'Indore' ? 'selected' : ''); ?>>Indore</option>
                            <option value="Kochi" <?php echo e(old('city') == 'Kochi' ? 'selected' : ''); ?>>Kochi</option>
                            <option value="Mumbai" <?php echo e(old('city') == 'Mumbai' ? 'selected' : ''); ?>>Mumbai</option>
                            <option value="Mysore" <?php echo e(old('city') == 'Mysore' ? 'selected' : ''); ?>>Mysore</option>
                            <option value="Noida" <?php echo e(old('city') == 'Noida' ? 'selected' : ''); ?>>Noida</option>
                            <option value="Pune" <?php echo e(old('city') == 'Pune' ? 'selected' : ''); ?>>Pune</option>
                            <option value="Trivandrum" <?php echo e(old('city') == 'Trivandrum' ? 'selected' : ''); ?>>Trivandrum</option>
                            <option value="Vizag" <?php echo e(old('city') == 'Vizag' ? 'selected' : ''); ?>>Vizag</option>
                        </select>
                    </div>
                </div>
            </div>
 
            <div class="form-group">
                <label for="presentaddress" class="col-md-4 control-label">Present Address</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group"><textarea class="form-control custom-mine <?php if ($errors->has('presentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="presentaddress" placeholder="Enter your present address" name="presentaddress" value="<?php echo e(old('presentaddress')); ?>" required><?php echo e(Request::old('presentaddress')); ?></textarea></div>
                </div>
                <?php if ($errors->has('presentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentaddress'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>    
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-check">
                <input type="checkbox" class="form-check-input" id="same" name="same" onclick="permanent(this.form)">
                <label class="form-check-label" for="same">Check this if your present and permanent address are same.</label>
            </div><br>

            <script language="JavaScript">
                function permanent(p) {
                    if(p.same.checked == true)
                        p.permanentaddress.value = p.presentaddress.value;
                    else
                        p.permanentaddress.value = "";
                }
            </script>
            
            <div class="form-group">
                <label for="permanentaddress" class="col-md-4 control-label">Permanent Address</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group"><textarea class="form-control custom-mine <?php if ($errors->has('permanentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('permanentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="permanentaddress" placeholder="Enter your permanent address" name="permanentaddress" value="<?php echo e(old('permanentaddress')); ?>" required><?php echo e(Request::old('permanentaddress')); ?></textarea></div>
                </div>
                <?php if ($errors->has('permanentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('permanentaddress'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>    
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
                <label for="officeaddress" class="col-md-4 control-label">Office Address</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group"><textarea class="form-control custom-mine <?php if ($errors->has('officeaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="officeaddress" placeholder="Enter your office address" name="officeaddress" value="<?php echo e(old('officeaddress')); ?>" required><?php echo e(Request::old('officeaddress')); ?></textarea></div>
                </div>
                <?php if ($errors->has('officeaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeaddress'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

        </div>

        <div class="col-md-6">

            <div class="form-group">
                <label for="yearsinbusiness" class="col-md-8 control-label">No. of years in business</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group"><input type="number" min="0" step="0.01" class="form-control custom-mine <?php if ($errors->has('yearsinbusiness')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinbusiness'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearsinbusiness" placeholder="Enter no. of years in business" name="yearsinbusiness" value="<?php echo e(old('yearsinbusiness')); ?>" required></div>
                </div>
                <?php if ($errors->has('yearsinbusiness')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinbusiness'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
                <label for="yearsincity" class="col-md-8 control-label">No. of years in current city</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group"><input type="number" min="0" step="0.01" class="form-control custom-mine <?php if ($errors->has('yearsincity')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsincity'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearsincity" placeholder="Enter no. of years in current city" name="yearsincity" value="<?php echo e(old('yearsincity')); ?>" required></div>
                </div>
                <?php if ($errors->has('yearsincity')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsincity'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
                <label for="yearsinpresentaddress" class="col-md-8 control-label">No. of years in present address</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group"><input type="number" min="0" step="0.01" class="form-control custom-mine <?php if ($errors->has('yearsinpresentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinpresentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearsinpresentaddress" placeholder="Enter no. of years in present address" name="yearsinpresentaddress" value="<?php echo e(old('yearsinpresentaddress')); ?>" required></div>
                </div>
                <?php if ($errors->has('yearsinpresentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinpresentaddress'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            
            <div class="form-group">
                <label>Type of residence</label>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="residence" id="rented" value="Rented" <?php echo e(old('residence') == "Rented" ? 'checked' : ''); ?> required>
                    <label class="col-md-2 control-label form-check-label" for="rented">Rented</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="residence" id="owned" value="Owned" <?php echo e(old('residence') == "Owned" ? 'checked' : ''); ?> required>
                    <label class="col-md-2 control-label form-check-label" for="owned">Owned</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input form-check-inline" type="radio" name="residence" id="parentsowned" value="Parents Owned" <?php echo e(old('residence') == "Parents Owned" ? 'checked' : ''); ?> required>
                    <label class="col-md-2 control-label form-check-label" for="parentsowned">Parents Owned</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input form-check-inline" type="radio" name="residence" id="other" value="other" <?php echo e(old('residence') == "Other" ? 'checked' : ''); ?> required>
                    <label class="col-md-2 control-label form-check-label" for="other">Other</label>
                </div>
            </div>
            
            <div class="form-group">
                <label class="col-md-4 control-label">Company</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group">
                        <select class="custom-select custom-mine selectpicker form-control" name="company" required>
                        <option selected>Choose ...</option>
                        <option value="Private Ltd." <?php echo e(old('company') == 'Private Ltd.' ? 'selected' : ''); ?>>Private Ltd.</option>
                        <option value="Proprietorship" <?php echo e(old('company') == 'Proprietorship' ? 'selected' : ''); ?>>Proprietorship</option>
                        <option value="Partnership" <?php echo e(old('company') == 'Partnership' ? 'selected' : ''); ?>>Partnership</option>
                        <option value="LLC" <?php echo e(old('company') == 'LLC' ? 'selected' : ''); ?>>LLC</option>
                        <option value="LLP" <?php echo e(old('company') == 'LLP' ? 'selected' : ''); ?>>LLP</option>
                    </select>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label>Any existing loans</label>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="existingloans" id="existingloansyes" value="Yes" <?php echo e(old('existingloans') == "Yes" ? 'checked' : ''); ?> required>
                    <label class="col-md-2 control-label form-check-label" for="existingloansyes">Yes</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="existingloans" id="existingloansno" value="No" <?php echo e(old('existingloans') == "No" ? 'checked' : ''); ?> required>
                    <label class="col-md-2 control-label form-check-label" for="existingloansno">No</label>
                </div>
            </div>

            <div class="form-group">
                <label>Marital Status</label>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="maritalstatus" id="married" value="Married" <?php echo e(old('maritalstatus') == "Married" ? 'checked' : ''); ?> required>
                    <label class="col-md-2 control-label form-check-label" for="married">Married</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="maritalstatus" id="single" value="Single" <?php echo e(old('maritalstatus') == "Single" ? 'checked' : ''); ?> required>
                    <label class="col-md-2 control-label form-check-label" for="single">Single</label>
                </div>
            </div>
            
            <div class="form-group">
                <label for="profit" class="col-md-4 control-label">Net profit</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group"><input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('profit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('profit'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="profit" placeholder="Enter last year's net profit as per ITR" name="profit" value="<?php echo e(old('profit')); ?>" required></div>
                </div>
                <?php if ($errors->has('profit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('profit'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
                <label for="turnover" class="col-md-4 control-label">Gross turnover</label>
                <div class="col-md-8 inputGroupContainer">
                    <div class="input-group"><input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('turnover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('turnover'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="turnover" placeholder="Enter last year's turnover as per ITR" name="turnover" value="<?php echo e(old('turnover')); ?>" required></div>
                </div>
                <?php if ($errors->has('turnover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('turnover'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

        </div>

    </div>

    <br>
    <div class="form-check">
        <input type="checkbox" class="form-check-input" id="proceed" name="proceed" required>
        <label for="proceed"><small>By submitting, you agree to the <a href="<?php echo e(url('/info#privacy_policy')); ?>" target="blank" style="text-decoration: none; color: whitesmoke"><b>Terms and Conditions</b></a> of Secure Credit & its representatives to contact you.</small></label>
    </div>
    
    <center><button type="submit" class="btn btn-primary">Submit</button></center>
    
    </form>

    <hr style="background-color:white;">

    <nav class="navbar navbar-expand navbar-light bg-light">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav menu mr-auto">
            <li class="nav-item">
              <h4><a class="nav-link menu-btn" href="#about">Overview <span class="sr-only">(current)</span></a></h4>
            </li>
            <li class="nav-item">
              <h4><a class="nav-link menu-btn" href="#contact">Offers & Schemes</a></h4>
            </li>
            <li class="nav-item">
              <h4><a class="nav-link menu-btn" href="#misc">Eligibility</a></h4>
            </li>
          </ul>
        </div>
    </nav>

    <div class="menu-content about" style="color:black;">
        <div class="jumbotron">
            Business Loans being unsecured loans do not require any collateral from the applicant. Applicant does not require providing any asset like car or house to avail business loan.<br>
            Each business is unique & has specific requirements. The small business loan is safest & easiest option to appropriately finance the business objectives. Banks & financial institutions offer tailor made loans based on nature, scope & goal of the requirements.
            <br><br><b>Types of Business Loans</b><br>
            There are several type of business investments available in the market that can be considered as a business loan.<br>
            Here’s a list of some common types of Business Loan:<br>
            <h6><a href="<?php echo e(url('/business_loan_form')); ?>"><b>Loans for Self-employed Entrepreneurs</b></a></h6>
            Business loan are offered by various banks & financial institutions across the country are customized & customer centric with a minimum interest rate for Business or MSME loans starting from 14.99% and onwards.<br>
            <h6><a href="<?php echo e(url('/invoice_discounting_form')); ?>"><b>Invoice discounting</b></a></h6>
            Invoice discounting is probably the simplest form of invoice finance. As with all types of invoice finance, with invoice discounting you sell unpaid invoices to a lender and they give you a cash advance that’s a percentage of the invoice’s value. Once your customer has paid the invoice, the lender pays you the remaining balance minus their fee.
            <h6><a href="<?php echo e(url('/pos_based_loan_form')); ?>"><b>POS/Card swiping machine based loan</b></a></h6>
            POS based loans are offered to business which accepts credit/ debit card payments or online sales. Avail loans against card swipes of up to 300% of your monthly sales via POS machines. These collateral free loans are disbursed within 3 to 7 days. Minimum monthly sales via POS machines or online sales should be more than ₹50,000.
            <h6><a href="<?php echo e(url('/lease_rental_discounting_form')); ?>"><b>Lease rental discounting</b></a></h6>
            Lease Rental Discounting is a type of loans provided by financial institutions by using rental receipts as collateral. The financial institutions will examine long-term cash flow and provide the loan based on the exact amount. This loan is then payable by the rents promised.
            <h6><a href="<?php echo e(url('/invoice_discounting_form')); ?>"><b>Working Capital Loan</b></a></h6>
            A working capital loan is a loan that is taken to finance a company's everyday operations. These loans are not used to buy long-term assets or investments and are, instead, used to provide the working capital that covers a company's short-term operational needs.
        </div>
    </div>
    <div class="menu-content contact" style="color: black;">
        <div class="jumbotron">
            Checking your eligibility is a crucial step before applying for a loan. This will help you find out which loans you qualify for. If you apply for a loan you don’t qualify for, the lender will usually reject your loan application. A rejected loan application can adversely impact your credit rating.
            <div class="table-responsive">
                <table class="table table-bordered table-dark">
                    <thead>
                        <tr>
                            <th scope="col">Bank/NBFC</th>
                            <th scope="col">Interest Rate (per annum)</th>
                            <th scope="col">Loan Amount</th>
                            <th scope="col">Processing Fees</th>
                            <th scope="col">Pre-closure Charges</th>
                            <th scope="col">Locking Period</th>
                            <th scope="col">Loan Tenure</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>HDFC Bank</th>
                            <td>15.65% to 21.20% per annum</td>
                            <td>Rs.50,000 to Rs. 50 lakhs</td>
                            <td>Up to 2.5% of the loan amount (subject to a minimum fee of ₹2,359 & maximum fee of ₹88,500)</td>
                            <td>07-24 Months - 4% of the outstanding principal<br>
                                25-36 Months - 3% of the outstanding principal<br>
                                >36 Months - 2% of outstanding principal</td>
                            <td>6 months</td>
                            <td>12 months to 48 months</td>
                        </tr>
                        <tr>
                            <th>Fullerton India</th>
                            <td>17% to 21% per annum</td>
                            <td>Rs.1 lakh to Rs. 50 lakh</td>
                            <td>Up to 6.5% of the borrowed loan amount</td>
                            <td>07-17 Months - 7% of the outstanding principal<br>
                                18-23 Months - 5% of the outstanding principal<br>
                                24-35 Months - 3% of the outstanding principal<br>
                                >36 Months - NIL</td>
                            <td>6 months</td>
                            <td>12 months to 48 months</td>
                        </tr>
                        <tr>
                            <th>Tata Capital</th>
                            <td>19% per annum onwards</td>
                            <td>Rs.5 lakh to Rs. 50 lakhs</td>
                            <td>Up to 2.75% of the loan amount</td>
                            <td>As per the lender’s terms and conditions</td>
                            <td>9 months</td>
                            <td>12 months to 36 months</td>
                        </tr>
                        <tr>
                            <th>ICICI Bank</th>
                            <td>16.49% per annum onwards</td>
                            <td>Rs. 1 lakh to Rs. 40 lakh</td>
                            <td>Up to 2% of the loan amount</td>
                            <td>5% of the outstanding principal</td>
                            <td>6 months</td>
                            <td>12 months to 36 months</td>
                        </tr>
                        <tr>
                            <th>IDFC Bank</th>
                            <td>15% per annum onwards</td>
                            <td>Rs. 3 lakhs to Rs. 75 lakhs</td>
                            <td>Up to 2% of the loan amount</td>
                            <td>4 - 5% of the outstanding principal</td>
                            <td>6 months</td>
                            <td>6 months to 36 months</td>
                        </tr>
                        <tr>
                            <th>Lending Kart</th>
                            <td>12% per annum onwards</td>
                            <td>Rs. 1 lakh to Rs. 1 crore</td>
                            <td>Up to 2% of the loan amount</td>
                            <td>Nil foreclosure charges</td>
                            <td>1 months</td>
                            <td>1 month to 36 months</td>
                        </tr>
                        <tr>
                            <th>Kotak Bank</th>
                            <td>16% per annum onwards</td>
                            <td>Rs. 3 lakhs to Rs. 75 lakhs</td>
                            <td>Up to 2% of the loan amount</td>
                            <td>6% of the outstanding principal</td>
                            <td>12 months</td>
                            <td>24 months to 60 months</td>
                        </tr>
                        <tr>
                            <th>IndusInd Bank</th>
                            <td>14% per annum onwards</td>
                            <td>Rs. 1 lakh to Rs. 50 lakhs</td>
                            <td>Up to 2.50% of the loan amount</td>
                            <td>4 - 5% of the outstanding principal</td>
                            <td>12 months</td>
                            <td>12 months to 60 months</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <small>**(Subject to change as per Bank’s discretion from time to time)<br>
                ** Goods and Services tax (GST) will be charged extra as per the applicable rates, on all the charges and fees (wherever GST is applicable)                
            </small>                
        </div>
    </div>
    <div class="menu-content misc" style="color: black;">
        <div class="jumbotron">
            Each bank has specific requirements, criteria and eligibility factors. Mentioned below is the list of common banks document requirements, upon different banks the document list may vary.
            <div class="table-responsive">
                <table class="table table-bordered table-dark">
                    <head>
                        <tr>
                            <th scope="col">KYC Documents</th>
                            <td scope="col">Valid identity/Address/Date of Birth/Signature Proof</td>
                        </tr>
                        <tr>
                            <th scope="col">Business Continuity Proof</th>
                            <td scope="col">Proprietary Concern: Bank statement in firm name along with any of the document as mentioned in Business Continuity Proof.<br>Partnership: Deed and PAN card of Firm<br>Company: MOA/AOA/Certificate of Incorporation/PAN Card</td>
                        </tr>
                        <tr>
                            <th scope="col">Constitutional Documents</th>
                            <td scope="col">Flexible tenure up to 36 months</td>
                        </tr>
                        <tr>
                            <th scope="col">Ownership proof</th>
                            <td scope="col">Copy of Sales Deed/EC/Govt. Leased Deed/Latest Property tax receipt/Water bill along with Latest paid Electricity bill</td>
                        </tr>
                        <tr>
                            <th scope="col">Banking</th>
                            <td scope="col">Latest 12 months bank statements of all CA/SA/CC/OD account. All Documents should be self-attested</td>
                        </tr>
                        <tr>
                            <th scope="col">Financials</th>
                            <td scope="col">Copy of Latest 3 years ITR along with Computation and Acknowledgement<br>3 years financials with full schedules & audit report (Form 3CD & 3CB).<br>Details of all running loans</td>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript">
        var $content = $('.menu-content');
    
        function showContent(type) {
          $content.hide().filter('.' + type).show();
        }
    
        $('.menu').on('click', '.menu-btn', function(e) {
          showContent(e.currentTarget.hash.slice(1));
          e.preventDefault();
        }); 
    
        // show 'about' content only on page load (if you want)
        showContent('about');
    </script>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u181465707/domains/securecredit.in/securecredit/resources/views/forms/business_loan_form.blade.php ENDPATH**/ ?>