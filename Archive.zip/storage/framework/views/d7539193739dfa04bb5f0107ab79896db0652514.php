<?php $__env->startSection('title', 'Personal Loan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top: 20px">
    
    <div class="alert alert-info text-center" role="alert"><h4>
        For faster processing you can submit your documents online. (Recommended)<br>
        or You can also send the same via mail at <a href="mailto:documents@securecredit.in">documents@securecredit.in</a><br>
        or submit to our executive at your door step
    </h4></div>
    
    <form method="POST" action="<?php echo e(url('/personal_loan_second_form')); ?>" enctype="multipart/form-data" style="color: white">
        <?php echo csrf_field(); ?>
        
        <div class="form-check">
            <label for="photo">Upload your passport size photo</label>
            <input type="file" accept=".png,.jpg,.jpeg" class="form-control-file custom-mine <?php if ($errors->has('photo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="photo" name="photo" value="<?php echo e(old('photo')); ?>">
            <?php if ($errors->has('photo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photo'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div><br>

        <div class="form-check">
            <?php if($employmenttype == "Salaried"): ?>
                <label>Upload your latest 3 months payslip (in pdf)</label>
            <?php elseif($employmenttype == "Self Employed"): ?>
                <label>Upload your last 3 months ITR (in pdf)</label>
            <?php endif; ?>
            <input type="file" accept=".pdf" class="form-control-file custom-mine <?php if ($errors->has('pdfpayslip_1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfpayslip_1'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pdfpayslip_1" name="pdfpayslip_1" value="<?php echo e(old('pdfpayslip_1')); ?>">
            <input type="file" accept=".pdf" class="form-control-file custom-mine <?php if ($errors->has('pdfpayslip_2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfpayslip_2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pdfpayslip_2" name="pdfpayslip_2" value="<?php echo e(old('pdfpayslip_2')); ?>">
            <input type="file" accept=".pdf" class="form-control-file custom-mine <?php if ($errors->has('pdfpayslip_3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfpayslip_3'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pdfpayslip_3" name="pdfpayslip_3" value="<?php echo e(old('pdfpayslip_3')); ?>">
            <?php if ($errors->has('pdfpayslip_1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfpayslip_1'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <?php if ($errors->has('pdfpayslip_2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfpayslip_2'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <?php if ($errors->has('pdfpayslip_3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfpayslip_3'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div><br>
        
        <div class="form-check">
            <label for="photoaadharfront">Upload your Aadhar card's front side photo</label>
            <input type="file" accept=".png,.jpg,.jpeg" class="form-control-file custom-mine <?php if ($errors->has('photoaadharfront')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photoaadharfront'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="photoaadharfront" name="photoaadharfront" value="<?php echo e(old('photoaadharfront')); ?>">
            <?php if ($errors->has('photoaadharfront')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photoaadharfront'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div><br>
        
        <div class="form-check">
            <label for="photoaadharback">Upload your Aadhar card's back side photo</label>
            <input type="file" accept=".png,.jpg,.jpeg" class="form-control-file custom-mine <?php if ($errors->has('photoaadharback')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photoaadharback'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="photoaadharback" name="photoaadharback" value="<?php echo e(old('photoaadharback')); ?>">
            <?php if ($errors->has('photoaadharback')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photoaadharback'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div><br>
        
        <div class="form-check">
            <label for="photopan">Upload your PAN card's front side photo</label>
            <input type="file" accept=".png,.jpg,.jpeg" class="form-control-file custom-mine <?php if ($errors->has('photopan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photopan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="photopan" name="photopan" value="<?php echo e(old('photopan')); ?>">
            <?php if ($errors->has('photopan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photopan'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div><br>
        
        <div class="form-check">
            <label for="pdfbank">Upload your latest 3 months bank statements till date (in pdf)</label>
            <input type="file" accept=".pdf" class="form-control-file custom-mine <?php if ($errors->has('pdfbank')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfbank'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pdfbank" name="pdfbank" value="<?php echo e(old('pdfbank')); ?>">
            <?php if ($errors->has('pdfbank')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfbank'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div><br>
        
        <div class="form-check">
            <label for="rentalagreement">Upload your rental agreement, if any (in pdf)</label>
            <input type="file" accept=".png,.jpg,.jpeg,.pdf" class="form-control-file custom-mine <?php if ($errors->has('rentalagreement')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rentalagreement'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="rentalagreement" name="rentalagreement" value="<?php echo e(old('rentalagreement')); ?>">
            <?php if ($errors->has('rentalagreement')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rentalagreement'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div><br>
    
        <div class="form-check">
            <label for="electricitybill">Upload your latest month electricity bill (in pdf)</label>
            <input type="file" accept=".png,.jpg,.jpeg,.pdf" class="form-control-file custom-mine <?php if ($errors->has('electricitybill')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('electricitybill'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="electricitybill" name="electricitybill" value="<?php echo e(old('electricitybill')); ?>">
            <?php if ($errors->has('electricitybill')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('electricitybill'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div><br>

        <center><button type="submit" class="btn btn-primary">Submit</button></center>
        
    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/forms/personal_loan_second_form.blade.php ENDPATH**/ ?>