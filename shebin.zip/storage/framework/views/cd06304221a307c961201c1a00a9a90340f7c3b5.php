<?php $__env->startSection('title', 'Credit Card Balance Transfer'); ?>

<?php $__env->startSection('content'); ?>

<div class="text-center"><h3 style="color: whitesmoke">Apply for Credit Card Balance Transfer</h3></div>
<div class="container" style="margin-top: 20px">
    <form method="POST" action="<?php echo e(url('/credit_card_balance_transfer_form')); ?>" style="color: whitesmoke">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="name" placeholder="Enter your name (as per PAN card)" name="name" value="<?php echo e(old('name')); ?>" required>
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="email">Email address</label>
            <input type="email" class="form-control custom-mine <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" placeholder="Enter your email address" name="email" value="<?php echo e(old('email')); ?>" required>
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
        <div class="form-group">
            <label for="phone">Phone No.</label>
            <input type="tel" pattern="[6789][0-9]{9}" size="10" class="form-control custom-mine <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phone" placeholder="Enter your phone no." name="phone" value="<?php echo e(old('phone')); ?>" required>
            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label>City</label>
            <div class="input-group">
                <select class="custom-select custom-mine selectpicker form-control" name="city" required>
                    <option value="">Choose ...</option>
                    <option value="Ahmedabad" <?php echo e(old('city') == 'Ahmedabad' ? 'selected' : ''); ?>>Ahmedabad</option>
                    <option value="Bangalore" <?php echo e(old('city') == 'Bangalore' ? 'selected' : ''); ?>>Bangalore</option>
                    <option value="Chennai" <?php echo e(old('city') == 'Chennai' ? 'selected' : ''); ?>>Chennai</option>
                    <option value="Coimbatore" <?php echo e(old('city') == 'Coimbatore' ? 'selected' : ''); ?>>Coimbatore</option>
                    <option value="Delhi" <?php echo e(old('city') == 'Delhi' ? 'selected' : ''); ?>>Delhi</option>
                    <option value="Delhi NCR" <?php echo e(old('city') == 'Delhi NCR' ? 'selected' : ''); ?>>Delhi NCR</option>
                    <option value="Hyderabad" <?php echo e(old('city') == 'Hyderabad' ? 'selected' : ''); ?>>Hyderabad</option>
                    <option value="Indore" <?php echo e(old('city') == 'Indore' ? 'selected' : ''); ?>>Indore</option>
                    <option value="Kochi" <?php echo e(old('city') == 'Kochi' ? 'selected' : ''); ?>>Kochi</option>
                    <option value="Mumbai" <?php echo e(old('city') == 'Mumbai' ? 'selected' : ''); ?>>Mumbai</option>
                    <option value="Mysore" <?php echo e(old('city') == 'Mysore' ? 'selected' : ''); ?>>Mysore</option>
                    <option value="Noida" <?php echo e(old('city') == 'Noida' ? 'selected' : ''); ?>>Noida</option>
                    <option value="Pune" <?php echo e(old('city') == 'Pune' ? 'selected' : ''); ?>>Pune</option>
                    <option value="Trivandrum" <?php echo e(old('city') == 'Trivandrum' ? 'selected' : ''); ?>>Trivandrum</option>
                    <option value="Vizag" <?php echo e(old('city') == 'Vizag' ? 'selected' : ''); ?>>Vizag</option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <p><b>Have you availed moratorium offered by RBI ?</b></p>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="moratorium" value="No" id="moratoriumno" <?php echo e(old('moratorium') == "No" ? 'checked' : ''); ?> required>
                <label class="form-check-label" for="moratoriumno">No</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="moratorium" value="Yes" id="moratoriumyes" <?php echo e(old('moratorium') == "Yes" ? 'checked' : ''); ?> required>
                <label class="form-check-label" for="moratoriumyes">Yes</label>
            </div><br>
        </div>
        
        <div class="form-group">
            <p><b>Type of employment</b></p>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="employmenttype" value="Salaried" id="salaried" <?php echo e(old('employmenttype') == "Salaried" ? 'checked' : ''); ?> required onclick="check()">
                <label class="form-check-label" for="salaried">Salaried</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="employmenttype" value="Self Employed" id="selfemployed" <?php echo e(old('employmenttype') == "Self Employed" ? 'checked' : ''); ?> required onclick="check()">
                <label class="form-check-label" for="selfemployed">Self Employed</label>
            </div><br>
        </div>

        <div class="form-group" id="modeofsalary" style="display: none">
            <label>Salary mode of salary</label>
            <div class="input-group">
                <select class="custom-select custom-mine selectpicker form-control" name="modeofsalary" id="id_modeofsalary">
                    <option value="">Choose ...</option>
                    <optgroup label="Mode">
                        <option value="Cash" <?php echo e(old('modeofsalary') == "Cash" ? 'selected' : ''); ?>>Cash</option>
                        <option value="Cheque" <?php echo e(old('modeofsalary') == "Cheque" ? 'selected' : ''); ?>>Cheque</option>
                    </optgroup>
                    <optgroup label="Bank">
                        <option value="HDFC Bank" <?php echo e(old('modeofsalary') == "HDFC Bank" ? 'selected' : ''); ?>>HDFC Bank</option>
                        <option value="ICICI Bank" <?php echo e(old('modeofsalary') == "ICICI Bank" ? 'selected' : ''); ?>>ICICI Bank</option>
                        <option value="Kotak Mahindra" <?php echo e(old('modeofsalary') == "Kotak Mahindra" ? 'selected' : ''); ?>>Kotak Mahindra</option>
                        <option value="IndusInd Bank" <?php echo e(old('modeofsalary') == "IndusInd Bank" ? 'selected' : ''); ?>>IndusInd Bank</option>
                        <option value="RBL Bank" <?php echo e(old('modeofsalary') == "RBL Bank" ? 'selected' : ''); ?>>RBL Bank</option>
                        <option value="Federal Bank" <?php echo e(old('modeofsalary') == "Federal Bank" ? 'selected' : ''); ?>>Federal Bank</option>
                        <option value="South Indian Bank" <?php echo e(old('modeofsalary') == "South Indian Bank" ? 'selected' : ''); ?>>South Indian Bank</option>
                        <option value="Axis Bank" <?php echo e(old('modeofsalary') == "Axis Bank" ? 'selected' : ''); ?>>Axis Bank</option>
                        <option value="SBI" <?php echo e(old('modeofsalary') == "SBI" ? 'selected' : ''); ?>>SBI</option>
                        <option value="Canara Bank" <?php echo e(old('modeofsalary') == "Canara Bank" ? 'selected' : ''); ?>>Canara Bank</option>
                        <option value="Syndicate Bank" <?php echo e(old('modeofsalary') == "Syndicate Bank" ? 'selected' : ''); ?>>Syndicate Bank</option>
                        <option value="PNB" <?php echo e(old('modeofsalary') == "PNB" ? 'selected' : ''); ?>>PNB</option>
                        <option value="Union Bank of India" <?php echo e(old('modeofsalary') == "Union Bank of India" ? 'selected' : ''); ?>>Union Bank of India</option>
                        <option value="IDFC First Bank" <?php echo e(old('modeofsalary') == "IDFC First Bank" ? 'selected' : ''); ?>>IDFC First Bank</option>
                        <option value="Karnataka Bank" <?php echo e(old('modeofsalary') == "Karnataka Bank" ? 'selected' : ''); ?>>Karnataka Bank</option>
                        <option value="Karur Vysya Bank" <?php echo e(old('modeofsalary') == "Karur Vysya Bank" ? 'selected' : ''); ?>>Karur Vysya Bank</option>
                        <option value="Citi Bank" <?php echo e(old('modeofsalary') == "Citi Bank" ? 'selected' : ''); ?>>Citi Bank</option>
                        <option value="Standard Chartered" <?php echo e(old('modeofsalary') == "Standard Chartered" ? 'selected' : ''); ?>>Standard Chartered</option>
                        <option value="Dena Bank" <?php echo e(old('modeofsalary') == "Dena Bank" ? 'selected' : ''); ?>>Dena Bank</option>
                        <option value="Yes Bank" <?php echo e(old('modeofsalary') == "Yes Bank" ? 'selected' : ''); ?>>Yes Bank</option>
                        <option value="DBS Bank" <?php echo e(old('modeofsalary') == "DBS Bank" ? 'selected' : ''); ?>>DBS Bank</option>
                        <option value="HSBC Banking Corp." <?php echo e(old('modeofsalary') == "HSBC Banking Corp." ? 'selected' : ''); ?>>HSBC Banking Corp.</option>
                        <option value="Bank of Baroda" <?php echo e(old('modeofsalary') == "Bank of Baroda" ? 'selected' : ''); ?>>Bank of Baroda</option>
                        <option value="Indian Bank" <?php echo e(old('modeofsalary') == "Indian Bank" ? 'selected' : ''); ?>>Indian Bank</option>
                    </optgroup>
                </select>
            </div>
        </div>

        <div class="form-group" id="netsalary" style="display: none">
            <label for="netsalary">Net monthly salary</label>
            <input type="number" min="0" id="id_netsalary" class="form-control custom-mine <?php if ($errors->has('netsalary')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netsalary'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Enter net take home salary" name="netsalary" value="<?php echo e(old('netsalary')); ?>">
            <?php if ($errors->has('netsalary')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netsalary'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group" id="profit" style="display: none">
            <label for="profit">Net profit</label>
            <input type="number" min="0" id="id_profit" class="form-control custom-mine <?php if ($errors->has('profit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('profit'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Enter net proft as per last year ITR" name="profit" value="<?php echo e(old('profit')); ?>">
            <?php if ($errors->has('profit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('profit'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
        <div class="form-group" id="turnover" style="display: none">
            <label for="turnover">Gross turnover</label>
            <input type="number" min="0" id="id_turnover" class="form-control custom-mine <?php if ($errors->has('turnover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('turnover'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Enter gross turnover as per last year ITR" name="turnover" value="<?php echo e(old('turnover')); ?>">
            <?php if ($errors->has('turnover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('turnover'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
        <div class="form-group">
            <label for="noofcards">No. of cards</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('noofcards')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('noofcards'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="noofcards" placeholder="Enter total no. of cards owned by you" name="noofcards" value="<?php echo e(old('noofcards')); ?>" required>
            <?php if ($errors->has('noofcards')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('noofcards'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="totalcreditlimit">Total Credit Limit on all cards</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('totalcreditlimit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('totalcreditlimit'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="totalcreditlimit" placeholder="Enter total credit limit on all cards" name="totalcreditlimit" value="<?php echo e(old('totalcreditlimit')); ?>" required>
            <?php if ($errors->has('totalcreditlimit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('totalcreditlimit'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="currentoutstanding">Current Outstanding on all cards</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('currentoutstanding')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('currentoutstanding'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="currentoutstanding" placeholder="Enter current outstanding on all cards" name="currentoutstanding" value="<?php echo e(old('currentoutstanding')); ?>" required>
            <?php if ($errors->has('currentoutstanding')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('currentoutstanding'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="loanamount">Loan amount</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('loanamount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('loanamount'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="loanamount" placeholder="Enter required loan amount" name="loanamount" value="<?php echo e(old('loanamount')); ?>" required>
            <?php if ($errors->has('loanamount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('loanamount'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <p>Any delay in payment in last three months</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="delayinpayment" id="delayinpaymentyes" value="Yes" <?php echo e(old('delayinpayment') == "Yes" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="delayinpaymentyes">Yes</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="delayinpayment" id="delayinpaymentno" value="No" <?php echo e(old('delayinpayment') == "No" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="delayinpaymentno">No</label>
        </div><br>

        <br>
        <div class="form-check">
            <input type="checkbox" class="form-check-input" id="proceed" name="proceed" required>
            <label class="form-check-label" for="proceed">By submitting, you agree to the <a href="<?php echo e(url('/info#privacy_policy')); ?>" style="text-decoration: none; color: whitesmoke">Terms and Conditions</a> of Secure Credit & its representatives to contact you.</label>
        </div>
        
        <center><button type="submit" class="btn btn-primary">Submit</button></center>

    </form>

    <hr style="background-color:white;">

    <nav class="navbar navbar-expand navbar-light bg-light">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav menu mr-auto">
            <li class="nav-item">
              <a class="nav-link menu-btn" href="#about">Overview <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link menu-btn" href="#contact">Offers & Schemes</a>
            </li>
            
          </ul>
        </div>
    </nav>

    <div class="menu-content about" style="color:black;">
        <div class="jumbotron">
            Credit card is a medium that allows customer to make purchases and pay for them later. Consistent repayment will lead to maintain a good credit score. But sometimes dealing the credit card will be a burden and repayment becomes difficult.  In such circumstances, balance transfer can be a remedy to manage the credit card debt.
        </div>
    </div>
    <div class="menu-content contact" style="color: black;">
        <div class="jumbotron">
            The benefits that a borrower gets by making a credit card balance transfer are:<br><br>
            Transfer multiple credit card<br>
            It helps in transferring all existing credit card debts to a single account. Now the borrower can convert & payback all credit card debts from one place.<br><br>
            Better interest rates<br>
            Balance transfer credit cards helps in getting lower interest rate when compared to credit card charges. Interest rates on credit cards are about 3.5% per month while the interest rate on a balance transfer is usually around 1.8% per month.<br><br>
            Maintain Credit Score<br>
            Brought down interest will make it simpler for the cardholders to make payment and hence stabilize their credit score. They can even improve it with timely payments.<br><br>
            Quick and Easy<br>
            Comparing with personal loan credit card balance transfer is quick and transferred directly.  
        </div>
    </div>
    
    <script>
        function check() {
            if(document.getElementById("salaried").checked) {
                document.getElementById("modeofsalary").style.display = "block";
                document.getElementById("netsalary").style.display = "block";
                document.getElementById("id_modeofsalary").setAttribute("required", "true");
                document.getElementById("id_netsalary").setAttribute("required", "true");
                document.getElementById("profit").style.display = "none";
                document.getElementById("turnover").style.display = "none";
                document.getElementById("id_profit").removeAttribute("required");
                document.getElementById("id_turnover").removeAttribute("required");

            }
            else if(document.getElementById("selfemployed").checked) {
                document.getElementById("modeofsalary").style.display = "none";
                document.getElementById("netsalary").style.display = "none";
                document.getElementById("id_modeofsalary").removeAttribute("required");
                document.getElementById("id_netsalary").removeAttribute("required");
                document.getElementById("profit").style.display = "block";
                document.getElementById("turnover").style.display = "block";
                document.getElementById("id_profit").setAttribute("required", "true");
                document.getElementById("id_turnover").setAttribute("required", "true");
            }
        }
    </script>
    
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript">
        var $content = $('.menu-content');
    
        function showContent(type) {
          $content.hide().filter('.' + type).show();
        }
    
        $('.menu').on('click', '.menu-btn', function(e) {
          showContent(e.currentTarget.hash.slice(1));
          e.preventDefault();
        }); 
    
        // show 'about' content only on page load (if you want)
        showContent('about');
    </script>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/forms/credit_card_balance_transfer_form.blade.php ENDPATH**/ ?>