<?php echo e($slot); ?>

<?php /**PATH /home/u181465707/domains/securecredit.in/securecredit/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>