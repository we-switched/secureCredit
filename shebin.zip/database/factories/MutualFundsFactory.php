<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MutualFunds;
use Faker\Generator as Faker;

$factory->define(MutualFunds::class, function (Faker $faker) {
    return [
        //
    ];
});
