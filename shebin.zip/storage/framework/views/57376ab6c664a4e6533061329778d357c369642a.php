<?php $__env->startSection('title', 'Personal Loan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top: 20px">
    <form method="POST" action="<?php echo e(url('/personal_loan_form/'.$loan->id)); ?>" enctype="multipart/form-data" style="color: whitesmoke">
    <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
       
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="name" placeholder="Enter your name (as per PAN card)" name="name" value="<?php echo e(old('name', $loan->name)); ?>" required>
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="photo">Upload your passport size photo</label>
            <input type="file" class="form-control-file custom-mine <?php if ($errors->has('photo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="photo" name="photo">
            <?php if ($errors->has('photo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photo'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="email">Personal email address</label>
            <input type="email" class="form-control custom-mine <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" placeholder="Enter your personal email address" name="email" value="<?php echo e(old('email', $loan->email)); ?>" required>
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
        <div class="form-group">
            <label for="officeemail">Office email address</label>
            <input type="email" class="form-control custom-mine <?php if ($errors->has('officeemail')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeemail'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="officeemail" placeholder="Enter your office email address" name="officeemail" value="<?php echo e(old('officeemail', $loan->officeemail)); ?>" required>
            <?php if ($errors->has('officeemail')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeemail'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="phone">Phone No.</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phone" placeholder="Enter your phone no." name="phone" value="<?php echo e(old('phone', $loan->phone)); ?>" required>
            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <?php if(auth()->user()->role === "Admin"): ?>
        <p>Telecaller</p>
        <select class="custom-select custom-mine" name="telecaller" required>
            <option>Choose ... </option>
            <?php $__currentLoopData = $telecallers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telecaller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($telecaller->name); ?>" <?php echo e(($telecaller->name == $loan->telecaller) ? 'selected' : ''); ?>><?php echo e($telecaller->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <?php endif; ?>

        <p>Status</p>
        <select class="custom-select custom-mine" name="status" required>
            <option value="">Choose ...</option>
            <option value="Not Called" <?php echo e($loan->status == "Not Called" ? 'selected' : ''); ?>>Not Called</option>
            <option value="Not Doable" <?php echo e($loan->status == "Not Doable" ? 'selected' : ''); ?>>Not Doable</option>
            <option value="Not Eligible" <?php echo e($loan->status == "Not Eligible" ? 'selected' : ''); ?>>Not Eligible</option>
            <option value="Not Reachable" <?php echo e($loan->status == "Not Reachable" ? 'selected' : ''); ?>>Not Reachable</option>
            <option value="Not Interested" <?php echo e($loan->status == "Not Interested" ? 'selected' : ''); ?>>Not Interested</option>
            <option value="Wrong no." <?php echo e($loan->status == "Wrong no." ? 'selected' : ''); ?>>Wrong no.</option>
            <option value="Ringing" <?php echo e($loan->status == "Ringing" ? 'selected' : ''); ?>>Ringing</option>
            <option value="Follow Up" <?php echo e($loan->status == "Follow Up" ? 'selected' : ''); ?>>Follow Up</option>
            <option value="Meeting" <?php echo e($loan->status == "Meeting" ? 'selected' : ''); ?>>Meeting</option>
            <option value="DOC Pickup" <?php echo e($loan->status == "DOC Pickup" ? 'selected' : ''); ?>>DOC Pickup</option>
            <option value="Login" <?php echo e($loan->status == "Login" ? 'selected' : ''); ?>>Login</option>
            <option value="Rejected" <?php echo e($loan->status == "Rejected" ? 'selected' : ''); ?>>Rejected</option>
            <option value="Sanctioned" <?php echo e($loan->status == "Sanctioned" ? 'selected' : ''); ?>>Sanctioned</option>
            <option value="Disbursed" <?php echo e($loan->status == "Disbursed" ? 'selected' : ''); ?>>Disbursed</option>
            <option value="Repeated Lead" <?php echo e($loan->status == "Repeated Lead" ? 'selected' : ''); ?>>Repeated Lead</option>
        </select><br><br>

        <p>Select City</p>
        <select class="custom-select custom-mine" name="city" required>
            <option value="">Choose ...</option>
            <option value="Ahmedabad" <?php echo e($loan->city == "Ahmedabad" ? 'selected' : ''); ?>>Ahmedabad</option>
            <option value="Bangalore" <?php echo e($loan->city == "Bangalore" ? 'selected' : ''); ?>>Bangalore</option>
            <option value="Chennai" <?php echo e($loan->city == "Chennai" ? 'selected' : ''); ?>>Chennai</option>
            <option value="Coimbatore" <?php echo e($loan->city == "Coimbatore" ? 'selected' : ''); ?>>Coimbatore</option>
            <option value="Delhi" <?php echo e($loan->city == "Delhi" ? 'selected' : ''); ?>>Delhi</option>
            <option value="Delhi NCR" <?php echo e($loan->city == "Delhi NCR" ? 'selected' : ''); ?>>Delhi NCR</option>
            <option value="Hyderabad" <?php echo e($loan->city == "Hyderabad" ? 'selected' : ''); ?>>Hyderabad</option>
            <option value="Indore" <?php echo e($loan->city == "Indore" ? 'selected' : ''); ?>>Indore</option>
            <option value="Kochi" <?php echo e($loan->city == "Kochi" ? 'selected' : ''); ?>>Kochi</option>
            <option value="Mumbai" <?php echo e($loan->city == "Mumbai" ? 'selected' : ''); ?>>Mumbai</option>
            <option value="Mysore" <?php echo e($loan->city == "Mysore" ? 'selected' : ''); ?>>Mysore</option>
            <option value="Noida" <?php echo e($loan->city == "Noida" ? 'selected' : ''); ?>>Noida</option>
            <option value="Pune" <?php echo e($loan->city == "Pune" ? 'selected' : ''); ?>>Pune</option>
            <option value="Trivandrum" <?php echo e($loan->city == "Trivandrum" ? 'selected' : ''); ?>>Trivandrum</option>
            <option value="Vizag" <?php echo e($loan->city == "Vizag" ? 'selected' : ''); ?>>Vizag</option>
        </select><br><br>
       
        <p>Is it a Top-Up Loan ?</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="topup" value="No" <?php echo e($loan->topup == "No" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="topupno">No</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="topup" value="Yes" <?php echo e($loan->topup == "Yes" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="topupyes">Yes</label>
        </div><br>

        <p>Have you availed moratorium offered by RBI ?</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="moratorium" value="No" id="moratoriumno" <?php echo e($loan->moratorium == "No" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="moratoriumno">No</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="moratorium" value="Yes" id="moratoriumyes" <?php echo e($loan->moratorium == "Yes" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="moratoriumyes">Yes</label>
        </div><br>
        
        <div class="form-group">
            <label for="presentaddress">Present Address</label>
            <textarea class="form-control custom-mine <?php if ($errors->has('presentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="presentaddress" placeholder="Enter your present address" name="presentaddress" value="<?php echo e(old('presentaddress')); ?>" required><?php echo e(Request::old('presentaddress', $loan->presentaddress)); ?></textarea>
            <?php if ($errors->has('presentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentaddress'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>    
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="permanentaddress">Permanent Address</label>
            <textarea class="form-control custom-mine <?php if ($errors->has('permanentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('permanentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="permanentaddress" placeholder="Enter your permanent address" name="permanentaddress" value="<?php echo e(old('permanentaddress')); ?>" required><?php echo e(Request::old('permanentaddress', $loan->permanentaddress)); ?></textarea>
            <?php if ($errors->has('permanentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('permanentaddress'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="officeaddress">Office Address</label>
            <textarea class="form-control custom-mine <?php if ($errors->has('officeaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="officeaddress" placeholder="Enter your office address" name="officeaddress" value="<?php echo e(old('officeaddress')); ?>" required><?php echo e(Request::old('officeaddress', $loan->officeaddress)); ?></textarea>
            <?php if ($errors->has('officeaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeaddress'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <p> Type of residence </p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="residence" id="rented" value="Rented" <?php echo e($loan->residence == "Rented" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="rented">Rented</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="residence" id="owned" value="Owned" <?php echo e($loan->residence == "Owned" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="owned">Owned</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="residence" id="parentsowned" value="Parents Owned" <?php echo e($loan->residence == "Parents Owned" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="parentsowned">Parents Owned</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="residence" id="other" value="Other" <?php echo e($loan->residence == "Other" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="other">Other</label>
        </div> <br>

        <div class="form-group">
            <label for="yearsinblr">No. of years in Bengaluru</label>
            <input type="number" class="form-control custom-mine <?php if ($errors->has('yearsinblr')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinblr'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearsinblr" placeholder="Enter no. of years in Bengaluru" name="yearsinblr" value="<?php echo e(old('yearsinblr', $loan->yearsinblr)); ?>" required>
            <?php if ($errors->has('yearsinblr')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinblr'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="yearsinpresentaddress">No. of years in current residence</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('yearsinpresentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinpresentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearsinpresentaddress" placeholder="Enter no. of years in residing in present address" name="yearsinpresentaddress" value="<?php echo e(old('yearsinpresentaddress', $loan->yearsinpresentaddress)); ?>" required>
            <?php if ($errors->has('yearsinpresentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinpresentaddress'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="rent">If rented, monthly payable rent</label>
            <input type="number" class="form-control custom-mine <?php if ($errors->has('rent')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rent'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="rent" placeholder="Enter no. of years in Bengaluru" name="rent" value="<?php echo e(old('rent', $loan->rent)); ?>" required>
            <?php if ($errors->has('rent')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rent'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="qualification">Qualification</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('qualification')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('qualification'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="qualification" placeholder="Enter your qualification" name="qualification" value="<?php echo e(old('qualification', $loan->qualification)); ?>" required>
            <?php if ($errors->has('qualification')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('qualification'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="uniname">University's Name</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('uniname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('uniname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="uniname" placeholder="Enter your university's name" name="uniname" value="<?php echo e(old('uniname', $loan->uniname)); ?>" required>
            <?php if ($errors->has('uniname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('uniname'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="yearofpassing">Year of passing</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('yearofpassing')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearofpassing'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearofpassing" placeholder="Enter your year of passing" name="yearofpassing" value="<?php echo e(old('yearofpassing', $loan->yearofpassing)); ?>" required>
            <?php if ($errors->has('yearofpassing')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearofpassing'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <p>Marital Status</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="maritalstatus" id="married" value="Married" <?php echo e($loan->maritalstatus == "Married" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="married">Married</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="maritalstatus" id="single" value="Single" <?php echo e($loan->maritalstatus == "Single" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="single">Single</label>
        </div><br>

        <p>Any existing loans</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="existingloans" id="yes" value="Yes" <?php echo e($loan->existingloans == "Yes" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="yes">Yes</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="existingloans" id="no" value="No" <?php echo e($loan->existingloans == "No" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="no">No</label>
        </div><br>

        <div class="form-group">
            <label for="emi">If any existing loan/credit card, monthly EMI payable</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('emi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('emi'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="emi" placeholder="Enter monthly EMI payable" name="emi" value="<?php echo e(old('emi', $loan->emi)); ?>" required>
            <?php if ($errors->has('emi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('emi'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="reference1">Reference #1 Friend's name & Contact number</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('reference1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('reference1'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="reference1" placeholder="Enter your friend's name & contact number" name="reference1" value="<?php echo e(old('reference1', $loan->reference1)); ?>" required>
            <?php if ($errors->has('reference1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('reference1'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="reference2">Reference #2 Friend's name & Contact number</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('reference2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('reference2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="reference2" placeholder="Enter your friend's name & contact number" name="reference2" value="<?php echo e(old('reference2', $loan->reference2)); ?>" required>
            <?php if ($errors->has('reference2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('reference2'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="company">Company's name as per payslip</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('company')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="company" placeholder="Enter company's name" name="company" value="<?php echo e(old('company', $loan->company)); ?>" required>
            <?php if ($errors->has('company')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="pdfpayslip">Upload your latest 3 months payslip (in pdf)</label>
            <input type="file" class="form-control custom-mine <?php if ($errors->has('pdfpayslip')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfpayslip'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pdfpayslip" name="pdfpayslip" value="<?php echo e(old('pdfpayslip', $loan->pdfpayslip)); ?>">
            <?php if ($errors->has('pdfpayslip')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfpayslip'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
                    
        <div class="form-group">
            <label for="designation">Designation</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('designation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('designation'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="designation" placeholder="Enter your designation" name="designation" value="<?php echo e(old('designation', $loan->designation)); ?>" required>
            <?php if ($errors->has('designation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('designation'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
        <div class="form-group">
            <label for="department">Department</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('department')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('department'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="department" placeholder="Enter your department" name="department" value="<?php echo e(old('department', $loan->department)); ?>">
            <?php if ($errors->has('department')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('department'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="yearsincompany">No. of years in current company</label>
            <input type="number" class="form-control custom-mine <?php if ($errors->has('yearsincompany')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsincompany'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearsincompany" placeholder="Enter no. of years in current company" name="yearsincompany" value="<?php echo e(old('yearsincompany', $loan->yearsincompany)); ?>">
            <?php if ($errors->has('yearsincompany')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsincompany'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="workexperience">Total work experience</label>
            <input type="number" class="form-control custom-mine <?php if ($errors->has('workexperience')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('workexperience'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="workexperience" placeholder="Enter no. of years of work experience" name="workexperience" value="<?php echo e(old('workexperience', $loan->workexperience)); ?>">
            <?php if ($errors->has('workexperience')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('workexperience'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="netsalary">Net monthly salary/income</label>
            <input type="number" class="form-control custom-mine <?php if ($errors->has('netsalary')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netsalary'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="netsalary" placeholder="Enter net monthly salary/income" name="netsalary" value="<?php echo e(old('netsalary', $loan->netsalary)); ?>">
            <?php if ($errors->has('netsalary')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netsalary'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="mothersname">Mother's name</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('mothersname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mothersname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="mothersname" placeholder="Enter your mother's name" name="mothersname" value="<?php echo e(old('mothersname', $loan->mothersname)); ?>">
            <?php if ($errors->has('mothersname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mothersname'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="loanamount">Loan amount</label>
            <input type="number" class="form-control custom-mine <?php if ($errors->has('loanamount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('loanamount'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="loanamount" placeholder="Enter required loan amount" name="loanamount" value="<?php echo e(old('loanamount', $loan->loanamount)); ?>">
            <?php if ($errors->has('loanamount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('loanamount'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <p>Tenure</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="tenure" id="12" value="12" <?php echo e($loan->tenure == "12" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="12">12 months</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="tenure" id="24" value="24" <?php echo e($loan->tenure == "24" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="24">24 months</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="tenure" id="36" value="36" <?php echo e($loan->tenure == "36" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="36">36 months</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="tenure" id="48" value="48" <?php echo e($loan->tenure == "48" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="48">48 months</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="tenure" id="other" value="Other" <?php echo e($loan->tenure == "Other" ? 'checked' : ''); ?>>
            <label class="form-check-label">Other</label>
        </div><br>

        
        <div class="form-group">
            <label for="dob">Date of birth</label>
            <input type="date" class="form-control custom-mine <?php if ($errors->has('dob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dob'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="dob" name="dob" value="<?php echo e(old('dob', $loan->dob)); ?>">
            <?php if ($errors->has('dob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dob'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="aadhar">Aadhar number</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('aadhar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('aadhar'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="aadhar" placeholder="Enter your aadhar number" name="aadhar" value="<?php echo e(old('aadhar', $loan->aadhar)); ?>">
            <?php if ($errors->has('aadhar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('aadhar'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="photoaadharfront">Upload your Aadhar card's front side photo</label>
            <input type="file" class="form-control custom-mine <?php if ($errors->has('photoaadharfront')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photoaadharfront'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="photoaadharfront" name="photoaadharfront" value="<?php echo e(old('photoaadharfront', $loan->photoaadharfront)); ?>">
            <?php if ($errors->has('photoaadharfront')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photoaadharfront'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
            
        <div class="form-group">
            <label for="photoaadharback">Upload your Aadhar card's back side photo</label>
            <input type="file" class="form-control custom-mine <?php if ($errors->has('photoaadharback')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photoaadharback'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="photoaadharback" name="photoaadharback" value="<?php echo e(old('photoaadharback', $loan->photoaadharback)); ?>">
            <?php if ($errors->has('photoaadharback')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photoaadharback'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
            
        <div class="form-group">
            <label for="pan">PAN number</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('pan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pan" placeholder="Enter your PAN number" name="pan" value="<?php echo e(old('pan', $loan->pan)); ?>">
            <?php if ($errors->has('pan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pan'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="photopan">Upload your PAN card's front side photo</label>
            <input type="file" class="form-control custom-mine <?php if ($errors->has('photopan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photopan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="photopan" name="photopan" value="<?php echo e(old('photopan', $loan->photopan)); ?>">
            <?php if ($errors->has('photopan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photopan'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
            
        <p>Salary bank account name</p>
        <select class="custom-select custom-mine" name="bank" required>
            <option value="">Choose ...</option>
            <option value="HDFC Bank" <?php echo e($loan->bank == "HDFC Bank" ? 'selected' : ''); ?>>HDFC Bank</option>
            <option value="ICICI Bank" <?php echo e($loan->bank == "ICICI Bank" ? 'selected' : ''); ?>>ICICI Bank</option>
            <option value="Kotak Mahindra" <?php echo e($loan->bank == "Kotak Mahindra" ? 'selected' : ''); ?>>Kotak Mahindra</option>
            <option value="IndusInd Bank" <?php echo e($loan->bank == "IndusInd Bank" ? 'selected' : ''); ?>>IndusInd Bank</option>
            <option value="RBL Bank" <?php echo e($loan->bank == "RBL Bank" ? 'selected' : ''); ?>>RBL Bank</option>
            <option value="Federal Bank" <?php echo e($loan->bank == "Federal Bank" ? 'selected' : ''); ?>>Federal Bank</option>
            <option value="South Indian Bank" <?php echo e($loan->bank == "South Indian Bank" ? 'selected' : ''); ?>>South Indian Bank</option>
            <option value="Axis Bank" <?php echo e($loan->bank == "Axis Bank" ? 'selected' : ''); ?>>Axis Bank</option>
            <option value="SBI" <?php echo e($loan->bank == "SBI" ? 'selected' : ''); ?>>SBI</option>
            <option value="Canara Bank" <?php echo e($loan->bank == "Canara Bank" ? 'selected' : ''); ?>>Canara Bank</option>
            <option value="Syndicate Bank" <?php echo e($loan->bank == "Syndicate Bank" ? 'selected' : ''); ?>>Syndicate Bank</option>
            <option value="PNB" <?php echo e($loan->bank == "PNB" ? 'selected' : ''); ?>>PNB</option>
            <option value="Union Bank of India" <?php echo e($loan->bank == "Union Bank of India" ? 'selected' : ''); ?>>Union Bank of India</option>
            <option value="IDFC First Bank" <?php echo e($loan->bank == "IDFC First Bank" ? 'selected' : ''); ?>>IDFC First Bank</option>
            <option value="Karnataka Bank" <?php echo e($loan->bank == "Karnataka Bank" ? 'selected' : ''); ?>>Karnataka Bank</option>
            <option value="Karur Vysya Bank" <?php echo e($loan->bank == "Karur Vysya Bank" ? 'selected' : ''); ?>>Karur Vysya Bank</option>
            <option value="Citi Bank" <?php echo e($loan->bank == "Citi Bank" ? 'selected' : ''); ?>>Citi Bank</option>
            <option value="Standard Chartered" <?php echo e($loan->bank == "Standard Chartered" ? 'selected' : ''); ?>>Standard Chartered</option>
            <option value="Dena Bank" <?php echo e($loan->bank == "Dena Bank" ? 'selected' : ''); ?>>Dena Bank</option>
            <option value="Yes Bank" <?php echo e($loan->bank == "Yes Bank" ? 'selected' : ''); ?>>Yes Bank</option>
            <option value="DBS Bank" <?php echo e($loan->bank == "DBS Bank" ? 'selected' : ''); ?>>DBS Bank</option>
            <option value="HSBC Banking Corp." <?php echo e($loan->bank == "HSBC Banking Corp." ? 'selected' : ''); ?>>HSBC Banking Corp.</option>
            <option value="Bank of Baroda" <?php echo e($loan->bank == "Bank of Baroda" ? 'selected' : ''); ?>>Bank of Baroda</option>
            <option value="Indian Bank" <?php echo e($loan->bank == "Indian Bank" ? 'selected' : ''); ?>>Indian Bank</option>
        </select><br><br>

        <div class="form-group">
            <label for="pdfbank">Upload your latest 3 months bank statements till date (in pdf)</label>
            <input type="file" class="form-control custom-mine <?php if ($errors->has('pdfbank')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfbank'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pdfbank" name="pdfbank" value="<?php echo e(old('pdfbank', $loan->pdfbank)); ?>">
            <?php if ($errors->has('pdfbank')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfbank'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
                    
        <div class="form-group">
            <label for="pdfrentalagreement">Upload your rental agreement with latest month electricity bill (in pdf)</label>
            <input type="file" class="form-control custom-mine <?php if ($errors->has('pdfrentalagreement')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfrentalagreement'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pdfrentalagreement" name="pdfrentalagreement" value="<?php echo e(old('pdfrentalagreement', $loan->pdfrentalagreement)); ?>">
            <?php if ($errors->has('pdfrentalagreement')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfrentalagreement'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
                    
        <center><button type="submit" class="btn btn-primary">Submit</button></center>
        
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/edit/personal_loan_form.blade.php ENDPATH**/ ?>