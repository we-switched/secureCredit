<?php $__env->startSection('title', 'Secure Credit'); ?>

<?php $__env->startSection('content'); ?>

<h3 class="text-center" style="color: white">Business Loan Applicants <a href="<?php echo e(url('/business_loan_export')); ?>" style="text-decoration: none; color: whitesmoke"><i class="fa fa-download" aria-hidden="true"></i></a></h3>
<div class="container">
    <?php if($applicants->count() > 0): ?>
    <div class="table-responsive">
    <table class="table table-bordered table-dark" style="margin: 30px;">
        <thead>
            <tr>
                <?php if(auth()->user()->role == "Admin" || auth()->user()->role == "Telecaller"): ?>
                <th scope="col">Action</th>
                <?php endif; ?>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Phone No.</th>
                <th scope="col">Top-Up</th>
                <th scope="col">Moratorium</th>
                <th scope="col">Agent</th>
                <th scope="col">Telecaller</th>
                <th scope="col">Status</th>
                <th scope="col">City</th>
                <th scope="col">Present Address</th>
                <th scope="col">Permanent Address</th>
                <th scope="col">Office Address</th>
                <th scope="col">Years in Business</th>
                <th scope="col">Years in Bengaluru</th>
                <th scope="col">Years in Present Address</th>
                <th scope="col">Residence</th>
                <th scope="col">Existing Loans</th>
                <th scope="col">Turnover</th>
                <th scope="col">Profit</th>
                <th scope="col">Marital Status</th>
                <th scope="col">Company</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <?php if(auth()->user()->role == "Admin" || auth()->user()->role == "Telecaller"): ?>
                <td>
                    <a href="<?php echo e(url('/business_loan_form/'.$person->id)); ?>"><i class="fa fa-pencil-square-o float-left" style="color: whitesmoke; size: 10px; margin-top:2px;" aria-hidden="true"></i></a>
                    <form method="POST" action="<?php echo e(url('/business_loan/'.$person->id)); ?>"> <?php echo method_field('DELETE'); ?> <?php echo csrf_field(); ?> <button type="submit" style="background:none; margin-left:2px;"><i class="fa fa-trash float-right" style="color: whitesmoke; size:10px;" aria-hidden="true"></i></button></form>
                </td>
                <?php endif; ?>
                <td><?php echo e($person->name); ?></td>
                <td><a href="mailto:<?php echo e($person->email); ?>"><?php echo e($person->email); ?></a></td>
                <td><?php echo e($person->phone); ?></td>
                <td><?php echo e($person->topup); ?></td>
                <td><?php echo e($person->moratorium); ?></td>
                <td><?php echo e($person->agent); ?></td>
                <td><?php echo e($person->telecaller); ?></td>
                <td><?php echo e($person->status); ?></td>
                <td><?php echo e($person->city); ?></td>
                <td><?php echo e($person->presentaddress); ?></td>
                <td><?php echo e($person->permanentaddress); ?></td>
                <td><?php echo e($person->officeaddress); ?></td>
                <td><?php echo e($person->yearsinbusiness); ?></td>
                <td><?php echo e($person->yearsinblr); ?></td>
                <td><?php echo e($person->yearsinpresentaddress); ?></td>
                <td><?php echo e($person->residence); ?></td>
                <td><?php echo e($person->existingloans); ?></td>
                <td><?php echo e($person->turnover); ?></td>
                <td><?php echo e($person->profit); ?></td>
                <td><?php echo e($person->maritalstatus); ?></td>
                <td><?php echo e($person->company); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    <?php else: ?>
        <h3 class="text-center" style="color: white">No Applications yet!</h3>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/details/business_loan.blade.php ENDPATH**/ ?>