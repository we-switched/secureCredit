<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\InvoiceDiscounting;
use Faker\Generator as Faker;

$factory->define(InvoiceDiscounting::class, function (Faker $faker) {
    return [
        //
    ];
});
