<?php $__env->startSection('title', 'Secure Credit'); ?>

<?php $__env->startSection('content'); ?>

<h3 class="text-center" style="color: whitesmoke">Savings Account Applicants <a href="<?php echo e(url('/savings_account_export')); ?>" style="text-decoration: none; color: whitesmoke"><i class="fa fa-download" aria-hidden="true"></i></a></h3>

<div class="container">
    <?php if($applicants->count() > 0): ?>
        <table class="table table-bordered table-dark" style="margin: 30px;">
            <head>
                <tr>
                    <?php if(auth()->user()->role == "Admin" || auth()->user()->role == "Telecaller"): ?>
                    <th scope="col">Action</th>
                    <?php endif; ?>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone No.</th>
                    <th scope="col">Agent</th>
                    <th scope="col">Telecaller</th>
                    <th scope="col">Status</th>
                    <th scope="col">City</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if(auth()->user()->role == "Admin" || auth()->user()->role == "Telecaller"): ?>
                        <td>
                            <a href="<?php echo e(url('/savings_account_form/'.$person->id)); ?>"><i class="fa fa-pencil-square-o float-left" style="color: whitesmoke; size: 10px; margin-top:2px;" aria-hidden="true"></i></a>
                            <form method="POST" action="<?php echo e(url('/savings_account/'.$person->id)); ?>"> <?php echo method_field('DELETE'); ?> <?php echo csrf_field(); ?> <button type="submit" style="background:none; margin-left:2px;"><i class="fa fa-trash float-right" style="color: whitesmoke; size:10px;" aria-hidden="true"></i></button></form>
                        </td>
                        <?php endif; ?>
                        <td><?php echo e($person->name); ?></td>
                        <td><a href="mailto:<?php echo e($person->email); ?>"><?php echo e($person->email); ?></a></td>
                        <td><?php echo e($person->phone); ?></td>
                        <td><?php echo e($person->agent); ?></td>
                        <td><?php echo e($person->telecaller); ?></td>
                        <td><?php echo e($person->status); ?></td>
                        <td><?php echo e($person->city); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <h3 class="text-center" style="color: white">No Applications yet!</h3>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/details/savings_account.blade.php ENDPATH**/ ?>