<?php $__env->startSection('title', 'Personal Loan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top: 20px">
    <form method="POST" action="<?php echo e(url('/personal_loan_form')); ?>" enctype="multipart/form-data" style="color: white">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6">

                <div class="form-group">
                    <label for="name" class="col-md-4 control-label">Name</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="name" placeholder="Enter your name (as per PAN card)" name="name" value="<?php echo e(old('name')); ?>" required></div>
                    </div>
                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
    
                <?php if(auth()->guard()->check()): ?>
                <div class="form-group">
                    <label for="photo">Upload your passport size photo</label>
                    <input type="file" class="form-control-file custom-mine" id="photo" name="photo">
                </div>
                <?php endif; ?>

                <div class="form-group">
                    <label for="phone" class="col-md-4 control-label">Phone No.</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phone" placeholder="Enter your phone no." name="phone" value="<?php echo e(old('phone')); ?>" required></div>
                    </div>
                    <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
    
                <div class="form-group">
                    <p><b>Is it a Top-Up Loan ?</b></p>
                    <div class="form-check form-check-inline">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="topup" value="No" checked>
                            <label class="col-md-2 control-label" for="topupno">No</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="topup" value="Yes">
                            <label class="col-md-2 control-label" for="topupyes">Yes</label>
                        </div><br>
                    </div>
                </div>
                    
                <div class="form-group">
                    <label for="officeemail" class="col-md-8 control-label">Office Email Address</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="email" class="form-control custom-mine <?php if ($errors->has('officeemail')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeemail'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="officeemail" placeholder="Enter your office email address" name="officeemail" value="<?php echo e(old('officeemail')); ?>" required></div>
                    </div>
                    <?php if ($errors->has('officeemail')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeemail'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="presentaddress" class="col-md-4 control-label">Present Address</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><textarea class="form-control custom-mine <?php if ($errors->has('presentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="presentaddress" placeholder="Enter your present address" name="presentaddress" value="<?php echo e(old('presentaddress')); ?>" required><?php echo e(Request::old('presentaddress')); ?></textarea></div>
                    </div>
                    <?php if ($errors->has('presentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentaddress'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>    
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
    
                <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="same" name="same" onclick="permanent(this.form)">
                    <label class="form-check-label" for="same">Check this if your present and permanent address are same.</label>
                </div><br>

                <script language="JavaScript">
                    function permanent(p) {
                        if(p.same.checked == true) {
                            p.permanentaddress.value = p.presentaddress.value;
                            document.getElementById('permanentaddress').setAttribute('readonly', true); 
                        }
                        else
                            document.getElementById('permanentaddress').setAttribute('readonly', false); 
                            p.permanentaddress.value = "";
                    }
                </script>

                <div class="form-group">
                    <label for="yearsinblr" class="col-md-8 control-label">No. of years in Bangalore</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="number" class="form-control custom-mine <?php if ($errors->has('yearsinblr')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinblr'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearsinblr" placeholder="Enter no. of years in bangalore" name="yearsinblr" value="<?php echo e(old('yearsinblr')); ?>" required></div>
                    </div>
                    <?php if ($errors->has('yearsinblr')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinblr'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="rent" class="col-md-8 control-label">If rented, monthly payable rent</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="number" class="form-control custom-mine <?php if ($errors->has('rent')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rent'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="rent" placeholder="Enter monthly payable rent" name="rent" value="<?php echo e(old('rent')); ?>" required></div>
                    </div>
                    <?php if ($errors->has('rent')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rent'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="uniname" class="col-md-4 control-label">University's Name</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('uniname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('uniname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="uniname" placeholder="Enter your university's name" name="uniname" value="<?php echo e(old('uniname')); ?>" required></div>
                    </div>
                    <?php if ($errors->has('uniname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('uniname'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
   
                <div class="form-group">
                    <p><b>Marital Status</b></p>
                    <div class="form-check form-check-inline">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="maritalstatus"  id="married" value="married">
                            <label class="col-md-2 control-label" for="married">Married</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="maritalstatus" id="single" value="single">
                            <label class="col-md-2 control-label" for="single">Single</label>
                        </div><br>
                    </div>
                </div>

                <div class="form-group">
                    <label for="reference1" class="col-md-8 control-label">Reference #1 Friend's name & Contact number</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('reference1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('reference1'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="reference1" placeholder="Enter your friend's name & contact number" name="reference1" value="<?php echo e(old('reference1')); ?>"></div>
                    </div>
                    <?php if ($errors->has('reference1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('reference1'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="emi" class="col-md-8 control-label">If any existing loan/credit card, monthly EMI payable</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="number" class="form-control custom-mine <?php if ($errors->has('emi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('emi'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="emi" placeholder="Enter monthly EMI payable" name="emi" value="<?php echo e(old('emi')); ?>"></div>
                    </div>
                    <?php if ($errors->has('emi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('emi'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <?php if(auth()->guard()->check()): ?>
                <div class="form-group">
                    <label for="pdfpayslip" class="col-md-8 control-label">Upload your latest 3 months payslip (in pdf)</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="file" class="form-control custom-mine <?php if ($errors->has('pdfpayslip')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfpayslip'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pdfpayslip" name="pdfpayslip" value="<?php echo e(old('pdfpayslip')); ?>"></div>
                    </div>
                    <?php if ($errors->has('pdfpayslip')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfpayslip'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <?php endif; ?>

                <div class="form-group">
                    <label for="officeaddress" class="col-md-8 control-label">Office Address</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('officeaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="officeaddress" placeholder="Enter your office address" name="officeaddress" value="<?php echo e(old('officeaddress')); ?>"></div>
                    </div>
                    <?php if ($errors->has('officeaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeaddress'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="designation" class="col-md-4 control-label">Designation</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('designation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('designation'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="designation" placeholder="Enter your designation" name="designation" value="<?php echo e(old('designation')); ?>"></div>
                    </div>
                    <?php if ($errors->has('designation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('designation'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="workexperience" class="col-md-8 control-label">Total work experience</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="number" class="form-control custom-mine <?php if ($errors->has('workexperience')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('workexperience'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="workexperience" placeholder="Enter no. of years of work experience" name="workexperience" value="<?php echo e(old('workexperience')); ?>"></div>
                    </div>
                    <?php if ($errors->has('workexperience')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('workexperience'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            
                <div class="form-group">
                    <label for="mothersname" class="col-md-4 control-label">Mother's name</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('mothersname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mothersname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="mothersname" placeholder="Enter your mother's name" name="mothersname" value="<?php echo e(old('mothersname')); ?>"></div>
                    </div>
                    <?php if ($errors->has('mothersname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mothersname'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="dob" class="col-md-4 control-label">Date of birth</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="date" class="form-control custom-mine <?php if ($errors->has('dob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dob'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="dob" name="dob" value="<?php echo e(old('dob')); ?>"></div>
                    </div>
                    <?php if ($errors->has('dob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dob'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="aadhar" class="col-md-4 control-label">Aadhar number</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('aadhar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('aadhar'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="aadhar" placeholder="Enter your aadhar number" name="aadhar" value="<?php echo e(old('aadhar')); ?>"></div>
                    </div>
                    <?php if ($errors->has('aadhar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('aadhar'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <?php if(auth()->guard()->check()): ?>
                <div class="form-group">
                    <label for="photoaadharfront" class="col-md-8 control-label">Upload your Aadhar card's front side photo</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="file" class="form-control custom-mine <?php if ($errors->has('photoaadharfront')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photoaadharfront'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="photoaadharfront" name="photoaadharfront" value="<?php echo e(old('photoaadharfront')); ?>"></div>
                    </div>
                    <?php if ($errors->has('photoaadharfront')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photoaadharfront'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="photoaadharback" class="col-md-8 control-label">Upload your Aadhar card's back side photo</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="file" class="form-control custom-mine <?php if ($errors->has('photoaadharback')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photoaadharback'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="photoaadharback" name="photoaadharback" value="<?php echo e(old('photoaadharback')); ?>"></div>
                    </div>
                    <?php if ($errors->has('photoaadharback')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photoaadharback'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                <div class="form-group">
                    <label for="photopan" class="col-md-8 control-label">Upload your Aadhar card's back side photo</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="file" class="form-control custom-mine <?php if ($errors->has('photopan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photopan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="photopan" name="photopan" value="<?php echo e(old('photopan')); ?>"></div>
                    </div>
                    <?php if ($errors->has('photopan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photopan'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <?php endif; ?>

                <div class="form-group">
                    <label class="col-md-8 control-label">Salary bank account name</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group">
                            <select class="custom-select custom-mine selectpicker form-control" name="bank" required>
                            <option value="">Choose ...</option>
                            <option value="hdfc">HDFC Bank</option>
                            <option value="icici">ICICI Bank</option>
                            <option value="kotak">Kotak Mahindra</option>
                            <option value="indusind">IndusInd Bank</option>
                            <option value="rbl">RBL Bank</option>
                            <option value="federal">Federal Bank</option>
                            <option value="south">South Indian Bank</option>
                            <option value="axis">Axis Bank</option>
                            <option value="sbi">SBI</option>
                            <option value="canara">Canara Bank</option>
                            <option value="syndicate">Syndicate Bank</option>
                            <option value="pnb">PNB</option>
                            <option value="union">Union Bank of India</option>
                            <option value="idfc">IDFC First Bank</option>
                            <option value="karnataka">Karnataka Bank</option>
                            <option value="karurvysya">Karur Vysya Bank</option>
                            <option value="citi">Citi Bank</option>
                            <option value="standardchartered">Standard Chartered</option>
                            <option value="dena">Dena Bank</option>
                            <option value="yes">Yes Bank</option>
                            <option value="dbs">DBS Bank</option>
                            <option value="hsbc">HSBC Banking Corp.</option>
                            <option value="baroda">Bank of Baroda</option>
                            <option value="indian">Indian Bank</option>
                        </select>
                        </div>
                    </div>
                </div>
                 
                <?php if(auth()->guard()->check()): ?>
                <div class="form-group">
                    <label for="pdfbank" class="col-md-8 control-label">Upload your latest 3 months bank statements till date (in pdf)</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="file" class="form-control custom-mine <?php if ($errors->has('pdfbank')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfbank'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pdfbank" name="pdfbank" value="<?php echo e(old('pdfbank')); ?>"></div>
                    </div>
                    <?php if ($errors->has('pdfbank')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfbank'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="pdfrentalagreement" class="col-md-8 control-label">Upload your rental agreement with latest month electricity bill (in pdf)</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="file" class="form-control custom-mine <?php if ($errors->has('pdfrentalagreement')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfrentalagreement'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pdfrentalagreement" name="pdfrentalagreement" value="<?php echo e(old('pdfrentalagreement')); ?>"></div>
                    </div>
                    <?php if ($errors->has('pdfrentalagreement')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pdfrentalagreement'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <center><button type="submit" class="btn btn-primary">Submit</button></center>
                <?php endif; ?>

            </div>

            <div class="col-md-6">

                <div class="form-group">
                    <label for="email" class="col-md-4 control-label">Email address</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="email" class="form-control custom-mine <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" placeholder="Enter your email address" name="email" value="<?php echo e(old('email')); ?>" required></div>
                    </div> 
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label class="col-md-4 control-label">City</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group">
                            <select class="custom-select custom-mine selectpicker form-control" name="city" required>
                            <option value="">Choose ...</option>
                            <option value="Ahmedabad">Ahmedabad</option>
                            <option value="Bangalore">Bangalore</option>
                            <option value="Chennai">Chennai</option>
                            <option value="Coimbatore">Coimbatore</option>
                            <option value="Delhi">Delhi</option>
                            <option value="Delhi NCR">Delhi NCR</option>
                            <option value="Hyderabad">Hyderabad</option>
                            <option value="Indore">Indore</option>
                            <option value="Kochi">Kochi</option>
                            <option value="Mumbai">Mumbai</option>
                            <option value="Mysore">Mysore</option>
                            <option value="Noida">Noida</option>
                            <option value="Pune">Pune</option>
                            <option value="Trivandrum">Trivandrum</option>
                            <option value="Vizag">Vizag</option>
                            </select>
                        </div>
                    </div>
                </div>
                 
                <div class="form-group">
                    <p><b>Have you availed moratorium offered by RBI ?</b></p>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="moratorium" value="No" id="moratoriumno">
                        <label class="col-md-2 control-label" for="moratoriumno">No</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="moratorium" value="Yes" id="moratoriumyes">
                        <label class="col-md-2 control-label" for="moratoriumyes">Yes</label>
                    </div><br>
                </div>
                
                <div class="form-group">
                    <p><b>Type of residence</b></p>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="residence" id="rented" value="Rented">
                        <label class="col-md-2 control-label form-check-label" for="rented">Rented</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="residence" id="owned" value="Owned">
                        <label class="col-md-2 control-label form-check-label" for="owned">Owned</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input form-check-inline" type="radio" name="residence" id="parentsowned" value="Parents Owned">
                        <label class="col-md-2 control-label form-check-label" for="parentsowned">Parents Owned</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input form-check-inline" type="radio" name="residence" id="other" value="other">
                        <label class="col-md-2 control-label form-check-label" for="other">Other</label>
                    </div>
                </div><br>
                            
                <div class="form-group">
                    <label for="permanentaddress" class="col-md-4 control-label">Permanent Address</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><textarea class="form-control custom-mine <?php if ($errors->has('permanentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('permanentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="permanentaddress" placeholder="Enter your permanent address" name="permanentaddress" value="<?php echo e(old('permanentaddress')); ?>" required><?php echo e(Request::old('presentaddress')); ?></textarea></div>
                    </div>
                    <?php if ($errors->has('permanentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('permanentaddress'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>    
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="yearsinpresentaddress" class="col-md-8 control-label">No. of years in current residence</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="number" class="form-control custom-mine <?php if ($errors->has('yearsinpresentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinpresentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearsinpresentaddress" placeholder="Enter no. of years in residing in present address" name="yearsinpresentaddress" value="<?php echo e(old('yearsinpresentaddress')); ?>" required></div>
                    </div>
                    <?php if ($errors->has('yearsinpresentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinpresentaddress'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="qualification" class="col-md-4 control-label">Qualification</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('qualification')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('qualification'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="qualification" placeholder="Enter your qualification" name="qualification" value="<?php echo e(old('qualification')); ?>" required></div>
                    </div>
                    <?php if ($errors->has('qualification')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('qualification'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="yearofpassing" class="col-md-4 control-label">Year of passing</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="number" class="form-control custom-mine <?php if ($errors->has('yearofpassing')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearofpassing'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearofpassing" placeholder="Enter your year of passing" name="yearofpassing" value="<?php echo e(old('yearofpassing')); ?>" required></div>
                    </div>
                    <?php if ($errors->has('yearofpassing')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearofpassing'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                             
                <div class="form-group">
                    <p><b>Any existing loans</b></p>
                    <div class="form-check form-check-inline">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="existingloans" id="yes" value="Yes">
                            <label class="col-md-2 control-label" for="yes">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="existingloans" id="no" value="No">
                            <label class="col-md-2 control-label" for="no">No</label>
                        </div><br>
                    </div>
                </div>

                <div class="form-group">
                    <label for="reference2" class="col-md-8 control-label">Reference #2 Friend's name & Contact number</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('reference2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('reference2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="reference2" placeholder="Enter your friend's name & contact number" name="reference2" value="<?php echo e(old('reference2')); ?>"></div>
                    </div>
                    <?php if ($errors->has('reference2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('reference2'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="company" class="col-md-8 control-label">Company's name as per payslip</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('company')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="company" placeholder="Enter company's name" name="company" value="<?php echo e(old('company')); ?>"></div>
                    </div>
                    <?php if ($errors->has('company')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="department" class="col-md-4 control-label">Department</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('department')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('department'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="department" placeholder="Enter your department" name="department" value="<?php echo e(old('department')); ?>"></div>
                    </div>
                    <?php if ($errors->has('department')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('department'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="yearsincompany" class="col-md-8 control-label">No. of years in current company</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="number" class="form-control custom-mine <?php if ($errors->has('yearsincompany')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsincompany'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearsincompany" placeholder="Enter no. of years in current company" name="yearsincompany" value="<?php echo e(old('yearsincompany')); ?>"></div>
                    </div>
                    <?php if ($errors->has('yearsincompany')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsincompany'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <label for="netsalary" class="col-md-8 control-label">Net monthly salary/income</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="number" class="form-control custom-mine <?php if ($errors->has('netsalary')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netsalary'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="netsalary" placeholder="Enter net monthly salary/income" name="netsalary" value="<?php echo e(old('netsalary')); ?>"></div>
                    </div>
                    <?php if ($errors->has('netsalary')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netsalary'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
   
                <div class="form-group">
                    <label for="loanamount" class="col-md-4 control-label">Loan amount</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="number" class="form-control custom-mine <?php if ($errors->has('loanamount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('loanamount'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="loanamount" placeholder="Enter required loan amount" name="loanamount" value="<?php echo e(old('loanamount')); ?>"></div>
                    </div>
                    <?php if ($errors->has('loanamount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('loanamount'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group">
                    <p><b>Tenure</b></p>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="tenure" id="12" value="12">
                        <label class="col-md-4 control-label form-check-label" for="12">12 months</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="tenure" id="24" value="24">
                        <label class="col-md-4 control-label form-check-label" for="24">24 months</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="tenure" id="36" value="36">
                        <label class="col-md-4 control-label form-check-label" for="36">36 months</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="tenure" id="48" value="48">
                        <label class="col-md-4 control-label form-check-label" for="48">48 months</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="tenure" id="other" value="other">
                        <label class="col-md-4 control-label form-check-label" for="other">Other</label>
                    </div>
                </div><br>
                
                
                <div class="form-group">
                    <label for="pan" class="col-md-4 control-label">PAN number</label>
                    <div class="col-md-8 inputGroupContainer">
                        <div class="input-group"><input type="text" class="form-control custom-mine <?php if ($errors->has('pan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pan" placeholder="Enter your PAN number" name="pan" value="<?php echo e(old('pan')); ?>"></div>
                    </div>
                    <?php if ($errors->has('pan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pan'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

            </div>
        </div>
                
        <?php if(auth()->guard()->guest()): ?>
        <center><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Submit</button></center>
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
    </form>

    <hr style="background-color:white;">

    <nav class="navbar navbar-expand navbar-light bg-light">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav menu mr-auto">
            <li class="nav-item">
              <a class="nav-link menu-btn" href="#about">Overview <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link menu-btn" href="#contact">Offers & Schemes</a>
            </li>
            <li class="nav-item">
              <a class="nav-link menu-btn" href="#misc">Eligibility</a>
            </li>
          </ul>
        </div>
    </nav>

    <div class="menu-content about" style="color:black;">
        <div class="jumbotron">
            A personal loan is money borrowed for any urgent cash requirement, It can be taken for any general purposes like education, reconstruction of property/home renovation, a wedding expense, vacation etc. Most of the financial institutions offer Personal Loan up to Rs. 40 lakhs for salaried customers. Normally, it can be repaid over a period of 12 months to 60 months. 
            Banks typically have capped the monthly payment (EMI) on your loan to about approximately 60% – 70% of your monthly take home income. However, a customer cannot take a personal loan for any kind of bad investment or expense which is not approved by the banks or by the law.            
            If you are looking for some money to close your credit cards due opt for <a href="<?php echo e(url('/credit_card_balance_transfer_form')); ?>">credit card balance transfer</a> option for fast & minimal processing
        </div>
    </div>
    <div class="menu-content contact" style="color: black;">
        <div class="jumbotron">
            Checking your eligibility is a crucial step before applying for a loan. This will help you find out which loans you qualify for. If you apply for a loan you don’t qualify for, the lender will usually reject your loan application. A rejected loan application can adversely impact your credit rating.<br>
        <table class="table table-bordered table-dark">
                <thead>
                    <tr>
                        <th scope="col">Bank/NBFC</th>
                        <th scope="col">Interest Rate (per annum)</th>
                        <th scope="col">Loan Amount</th>
                        <th scope="col">Processing Fees</th>
                        <th scope="col">Part Payment</th>
                        <th scope="col">Pre-closure Charges</th>
                        <th scope="col">Locking Period</th>
                        <th scope="col">Loan Tenure</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th>HDFC Bank</th>
                        <td>10.99% to 20.00%</td>
                        <td>Rs. 50,000 to Rs. 40 lakhs</td>
                        <td>Up to 2.50% of the loan amount subject to a minimum of ₹1,999/- & Maximum of ₹25000/-</td>
                        <td>Up to 25% of Principal Outstanding allowed</td>
                        <td>13-24 Months - 4% of Principal outstanding plus GST<br>
                            25-36 Months - 3% of Principal outstanding plus GST<br>
                            37-48 Months - 2% of Principal outstanding plus GST<br>
                            After 48 months - NIL</td>
                        <td>12 months</td>
                        <td>12 months to 60 months</td>
                    </tr>
                    <tr>
                        <th>Fullerton Bank</th>
                        <td>12% to 25%</td>
                        <td>Rs. 65,000 to Rs. 20 lakhs</td>
                        <td>3% - 6% of the loan amount plus GST</td>
                        <td>Not available</td>
                        <td>7-17 Months - 7% of Principal outstanding plus GST<br>
                            18-23 months - 5% of Principal outstanding plus GST<br>
                            24-35 months - 3% of Principal outstanding plus GST<br>
                            After 36 months - NIL</td>
                        <td>12 months</td>
                        <td>12 months to 60 months</td>
                    </tr>
                    <tr>
                        <th>IDFC First Bank</th>
                        <td>11.69% - 15.00% (Top up rates starts from 11.50%)</td>
                        <td>Rs. 1 lakh to Rs. 20 lakhs</td>
                        <td>Up to 2.0% of the loan amount</td>
                        <td>Up to 40% of loan amount every year</td>
                        <td>3% on your principal outstanding plus GST</td>
                        <td>3 months</td>
                        <td>12 months to 60 months</td>
                    </tr>
                    <tr>
                        <th>ICICI Bank</th>
                        <td>11.50% to 16.75%</td>
                        <td>Rs. 50,000 to Rs. 25 lakhs</td>
                        <td>Up to 2.25% per annum of loan amount plus GST</td>
                        <td>Not available</td>
                        <td>5% per annum of principal outstanding plus GST</td>
                        <td>6 months</td>
                        <td>12 months to 60 months</td>
                    </tr>
                    <tr>
                        <th>Tata Capital</th>
                        <td>11.75% to 19.00%</td>
                        <td>Rs. 75,000 to Rs. 20 lakhs</td>
                        <td>From ₹999/- Up to 2.0% of the loan amount and applicable Service Tax</td>
                        <td>Up to 25% of the principal outstanding (2% of the amount paid + GST)<br>
                            *Maximum of 50% of the principal outstanding permissible</td>
                        <td>6-12 months - 4% of principal outstanding plus GST<br>
                            After 12 months - NIL<br>
                            Top Up - 5% of the principal outstanding</td>
                        <td>6 months</td>
                        <td>12 months to 72 months</td>
                    </tr>
                    <tr>
                        <th>Axis Bank</th>
                        <td>12.00% to 24.00%</td>
                        <td>Rs. 50,000 to Rs. 15 lakhs</td>
                        <td>Upto 2% of the loan amount plus GST</td>
                        <td>NIL</td>
                        <td>NIL</td>
                        <td>6 months</td>
                        <td>12 months to 60 months</td>
                    </tr>
                    <tr>
                        <th>Bajaj Finserv</th>
                        <td>12.00% to 16.00%</td>
                        <td>Rs. 1 lakh to Rs. 15 lakhs</td>
                        <td>Up to 3.99% of the loan amount</td>
                        <td>Should be more than 1 EMI (2% + applicable taxes on part-payment amount paid)</td>
                        <td>4% plus applicable taxes on principal outstanding</td>
                        <td>1 month</td>
                        <td>12 months to 60 months</td>
                    </tr>
                    <tr>
                        <th>Kotak Mahindra Bank</th>
                        <td>11.00% to 24.00%</td>
                        <td>Rs. 1 lakh to Rs. 30 lakhs</td>
                        <td>Up to 2.5% of the loan amount + GST and other applicable statutory levies</td>
                        <td>Not available</td>
                        <td>5% of the outstanding amount + GST on principal outstanding</td>
                        <td>12 months</td>
                        <td>12 months to 48 months</td>
                    </tr>
                    <tr>
                        <th>IndusInd Bank</th>
                        <td>11.49% to 20.00%</td>
                        <td>Rs. 1 lakh to Rs. 20 lakhs</td>
                        <td>Up to 2.50% of the loan amount plus tax</td>
                        <td>Not available</td>
                        <td>4% of the principal outstanding</td>
                        <td>Salaried:<br> 12 months<br><br>Self Employed:<br> 6 months</td>
                        <td>12 months to 60 months</td>
                    </tr>
                    <tr>
                        <th>IIFL</th>
                        <td>12.99% to 20.00%</td>
                        <td>Rs. 1 lakh to Rs. 20 lakhs</td>
                        <td>Upto 2% of the loan amount plus GST</td>
                        <td>Not available</td>
                        <td>Up to 4% of the Principal Outstanding<br>After 12 Months - NIL</td>
                        <td>6 months</td>
                        <td>12 months to 60 months</td>
                    </tr>
                    <tr>
                        <th>RBL Bank</th>
                        <td>14.00% to 20.00%</td>
                        <td>Rs. 1 lakh to Rs. 20 lakhs</td>
                        <td>1.5% of the loan amount (Non Refundable fee of Rs 7500 Upfront, Rest at the time of disbursal)</td>
                        <td>Not available</td>
                        <td>13-18 months - 4% of principal outstanding plus GST After 12 Months - 3% of principal outstanding plus GST</td>
                        <td>12 months</td>
                        <td>12 months to 60 months</td>
                    </tr>
                    <tr>
                        <th>Incred</th>
                        <td>11.49% to 20.00%</td>
                        <td>Rs. 50,000 to Rs. 7.5 lakhs</td>
                        <td>Starting at 1% plus GST</td>
                        <td>Not available</td>
                        <td>After 6 months subject to payment of standard pre-closure charges applicable</td>
                        <td>6 months</td>
                        <td>12 months to 60 months</td>
                    </tr>
                </tbody>
            </table>
            <small>
                **(Subject to change as per Bank’s discretion from time to time)<br>
                ** Goods and Services tax (GST) will be charged extra as per the applicable rates, on all the charges and fees (wherever GST is applicable)
            </small>                
        </div>
    </div>
    <div class="menu-content misc" style="color: black;">
        <div class="jumbotron">
            The eligibility criteria to get an online personal loan approval for salaried and self-employed individuals are based on some factors.<br>
            The following are the factors that influence your eligibility:
            <ul>
                <li>Monthly or annual income
                <li>Company or organisation you work for
                <li>Type of residence – own house or rented house
                <li>Area or city in which you live
                <li>Credit rating or credit history
                <li>Current debt-to-income ratio
            </ul>
            <h5>Documents Required for Personal Loan</h5>
            <b>For Salaried Individuals</b><br>
            <ul>
                <li>Identity & Age Proof
                <li>PAN Card
                <li>Residence proof - Passport driving licence, Voter ID, post paid/landline bill, utility bills (electricity/water/gas)
                <li>Bank statements for the last 3 months (preferably your salary account)
                <li>Salary Slips of last 3 months
                <li>Form 16 or Income Tax Returns of last 3 years
            </ul>
            <table class="table table-bordered table-dark">
                <head>
                    <tr>
                        <th scope="col">Employment Type</th>
                        <td scope="col">Salaried</td>
                    </tr>
                    <tr>
                        <th scope="col">Age</th>
                        <td scope="col">21 years – 60 years</td>
                    </tr>
                    <tr>
                        <th scope="col">Minimum Net Income (Monthly)</th>
                        <td scope="col">₹25,000</td>
                    </tr>
                    <tr>
                        <th scope="col">Work Experience</th>
                        <td scope="col">Employed at current company for at least 6/12 months</td>
                    </tr>
                </thead>
            </table>
            <b>For Self-Employed professionals</b><br>
            <ul>
                <li>Identity & Age Proof
                <li>PAN Card
                <li>Residence proof - Passport driving licence, Voter ID, post paid/landline bill, utility bills (electricity/water/gas)
                <li>Bank statements for the last 12 months 
                <li>Last 3 years Income Tax Returns with computation of Income
                <li>Last 3 years CA Certified / Audited Balance Sheet and Profit & Loss Account
            </ul>
            <table class="table table-bordered table-dark">
                <head>
                    <tr>
                        <th scope="col">Employment Type</th>
                        <td scope="col">Self-Employed</td>
                    </tr>
                    <tr>
                        <th scope="col">Age</th>
                        <td scope="col">21 years – 68 years</td>
                    </tr>
                    <tr>
                        <th scope="col">Gross Annual Income</th>
                        <td scope="col">₹5,00,000</td>
                    </tr>
                    <tr>
                        <th scope="col">Business Stability</th>
                        <td scope="col">Business tenure of at least 3 years (continuous) ITR of last 3 years</td>
                    </tr>
                </thead>
            </table>
            <small>**Business Turnover, Operation History, Business existence, credit score and profitability criteria are defined by the respective bank and NBFC.</small>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript">
        var $content = $('.menu-content');
    
        function showContent(type) {
          $content.hide().filter('.' + type).show();
        }
    
        $('.menu').on('click', '.menu-btn', function(e) {
          showContent(e.currentTarget.hash.slice(1));
          e.preventDefault();
        }); 
    
        // show 'about' content only on page load (if you want)
        showContent('about');
    </script>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/forms/personal_loan_form.blade.php ENDPATH**/ ?>