@extends('layouts.app')

@section('title', 'Career')

@section('content')

<div class="alert alert-info" role="alert">
    We have no job openings currently. Thank you for your time.
</div>

@endsection