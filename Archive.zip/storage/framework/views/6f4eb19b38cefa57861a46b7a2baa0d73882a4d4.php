

<?php $__env->startSection('title', 'Instant Loan'); ?>

<?php $__env->startSection('content'); ?>

<div class="text-center"><h3 style="color: whitesmoke">Apply for Instant Loan</h3></div>
<div class="container" style="margin-top: 20px">
    <form method="POST" action="<?php echo e(url('/instant_loan_form')); ?>" style="color: whitesmoke">
    <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="name" placeholder="Enter your name (as per PAN card)" name="name" value="<?php echo e(old('name')); ?>" required>
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="email">Email address</label>
            <input type="email" class="form-control custom-mine <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" placeholder="Enter your email address" name="email" value="<?php echo e(old('email')); ?>" required>
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="phone">Phone No.</label>
            <input type="tel" pattern="[6789][0-9]{9}" size="10" class="form-control custom-mine <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phone" placeholder="Enter your phone no." name="phone" value="<?php echo e(old('phone')); ?>" required>
            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label>City</label>
            <div class="input-group">
                <select class="custom-select custom-mine selectpicker form-control" name="city" required>
                    <option value="">Choose ...</option>
                    <option value="Ahmedabad" <?php echo e(old('city') == 'Ahmedabad' ? 'selected' : ''); ?>>Ahmedabad</option>
                    <option value="Bangalore" <?php echo e(old('city') == 'Bangalore' ? 'selected' : ''); ?>>Bangalore</option>
                    <option value="Chennai" <?php echo e(old('city') == 'Chennai' ? 'selected' : ''); ?>>Chennai</option>
                    <option value="Coimbatore" <?php echo e(old('city') == 'Coimbatore' ? 'selected' : ''); ?>>Coimbatore</option>
                    <option value="Delhi" <?php echo e(old('city') == 'Delhi' ? 'selected' : ''); ?>>Delhi</option>
                    <option value="Delhi NCR" <?php echo e(old('city') == 'Delhi NCR' ? 'selected' : ''); ?>>Delhi NCR</option>
                    <option value="Hyderabad" <?php echo e(old('city') == 'Hyderabad' ? 'selected' : ''); ?>>Hyderabad</option>
                    <option value="Indore" <?php echo e(old('city') == 'Indore' ? 'selected' : ''); ?>>Indore</option>
                    <option value="Kochi" <?php echo e(old('city') == 'Kochi' ? 'selected' : ''); ?>>Kochi</option>
                    <option value="Mumbai" <?php echo e(old('city') == 'Mumbai' ? 'selected' : ''); ?>>Mumbai</option>
                    <option value="Mysore" <?php echo e(old('city') == 'Mysore' ? 'selected' : ''); ?>>Mysore</option>
                    <option value="Noida" <?php echo e(old('city') == 'Noida' ? 'selected' : ''); ?>>Noida</option>
                    <option value="Pune" <?php echo e(old('city') == 'Pune' ? 'selected' : ''); ?>>Pune</option>
                    <option value="Trivandrum" <?php echo e(old('city') == 'Trivandrum' ? 'selected' : ''); ?>>Trivandrum</option>
                    <option value="Vizag" <?php echo e(old('city') == 'Vizag' ? 'selected' : ''); ?>>Vizag</option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label for="presentaddress">Present Address</label>
            <textarea class="form-control custom-mine <?php if ($errors->has('presentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="presentaddress" placeholder="Enter your present address" name="presentaddress" value="<?php echo e(old('presentaddress')); ?>" required><?php echo e(Request::old('presentaddress')); ?></textarea>
            <?php if ($errors->has('presentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentaddress'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>    
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-check">
            <input type="checkbox" class="form-check-input" id="same" name="same" onclick="permanent(this.form)">
            <label class="form-check-label" for="same">Check this if your present and permanent address are same.</label>
        </div><br>

        <script language="JavaScript">
            function permanent(p) {
                if(p.same.checked == true)
                    p.permanentaddress.value = p.presentaddress.value;
                else
                    p.permanentaddress.value = "";
            }
        </script>
        
        <div class="form-group">
            <label for="permanentaddress">Permanent Address</label>
            <textarea class="form-control custom-mine <?php if ($errors->has('permanentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('permanentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="permanentaddress" placeholder="Enter your permanent address" name="permanentaddress" value="<?php echo e(old('permanentaddress')); ?>" required><?php echo e(Request::old('permanentaddress')); ?></textarea>
            <?php if ($errors->has('permanentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('permanentaddress'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>    
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <p>Do you have Aadhar linked Mobile No. ?</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" id="aadharmobileno" name="aadharmobile" value="No" <?php echo e(old('aadharmobile') == "No" ? 'checked' : ''); ?> required>
            <label class="form-check-label" for="aadharmobileno">No</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" id="aadharmobileyes" name="aadharmobile" value="Yes" <?php echo e(old('aadharmobile') == "Yes" ? 'checked' : ''); ?> required>
            <label class="form-check-label" for="aadharmobileyes">Yes</label>
        </div><br>

        <div class="form-group">
            <label for="netincome">Monthly Income</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('netincome')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netincome'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="netincome" placeholder="Enter your net monthly income" name="netincome" value="<?php echo e(old('netincome')); ?>" required>
            <?php if ($errors->has('netincome')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('netincome'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="loanamount">Required Loan Amount</label>
            <input type="number" min="0" class="form-control custom-mine <?php if ($errors->has('loanamount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('loanamount'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="loanamount" placeholder="Enter required loan amount" name="loanamount" value="<?php echo e(old('loanamount')); ?>" required>
            <?php if ($errors->has('loanamount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('loanamount'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <p>Do you have internet banking access for your savings account ?</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" id="bankingaccessno" name="bankingaccess" value="No" <?php echo e(old('bankingaccess') == "No" ? 'checked' : ''); ?> required>
            <label class="form-check-label" for="bankingaccessno">No</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" id="bankingaccessyes" name="bankingaccess" value="Yes" <?php echo e(old('bankingaccess') == "Yes" ? 'checked' : ''); ?> required>
            <label class="form-check-label" for="bankingaccessyes">Yes</label>
        </div><br>

        <br>
        <div class="form-check">
            <input type="checkbox" class="form-check-input" id="proceed" name="proceed" required>
            <label for="proceed"><small>By submitting, you agree to the <a href="<?php echo e(url('/info#privacy_policy')); ?>" target="blank" style="text-decoration: none; color: whitesmoke"><b>Terms and Conditions</b></a> of Secure Credit & its representatives to contact you.</small></label>
        </div>
        
        <center><button type="submit" class="btn btn-primary">Submit</button></center>

    </form>

    <hr style="background-color:white;">

    <nav class="navbar navbar-expand navbar-light bg-light">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav menu mr-auto">
            <li class="nav-item">
                <h4><a class="nav-link menu-btn" href="#about">Overview <span class="sr-only">(current)</span></a></h4>
            </li>
            <li class="nav-item">
                <h4><a class="nav-link menu-btn" href="#contact">Eligibility</a></h4>
            </li>
          </ul>
        </div>
    </nav>

    <div class="menu-content about" style="color:black;">
        <div class="jumbotron">
            Instant Loan upto 2 lakhs with rate of interest starting from 12.5% per ANNUM.<br>Approval & Disbursal in 15 minutes through e-KYC.
        </div>
    </div>
    <div class="menu-content contact" style="color: black;">
        <div class="jumbotron">
            <ul>
                <li>Age 19 years above 
                <li>Current address proof Aadhar is mandatory
                <li>Minimum salary : 12k
                <li>Mobile number should be updated in Aadhar 
                <li>Should have internet banking access
            </ul>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript">
        var $content = $('.menu-content');
    
        function showContent(type) {
          $content.hide().filter('.' + type).show();
        }
    
        $('.menu').on('click', '.menu-btn', function(e) {
          showContent(e.currentTarget.hash.slice(1));
          e.preventDefault();
        }); 
    
        // show 'about' content only on page load (if you want)
        showContent('about');
    </script>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cloudxlab/Downloads/shebin/securecredit/resources/views/forms/instant_loan_form.blade.php ENDPATH**/ ?>