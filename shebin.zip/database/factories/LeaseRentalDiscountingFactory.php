<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\LeaseRentalDiscounting;
use Faker\Generator as Faker;

$factory->define(LeaseRentalDiscounting::class, function (Faker $faker) {
    return [
        //
    ];
});
