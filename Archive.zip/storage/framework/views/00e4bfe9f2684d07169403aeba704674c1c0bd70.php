<?php $__env->startSection('title', 'Savings Account'); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top: 20px">
    
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <a href="<?php echo e(url('/personal_loan_form')); ?>"><button class="btn btn-primary" type="button">Personal Loan Top-Up </button></a>
        </div>
        <div class="col-md-3">
          <a href="<?php echo e(url('/business_loan_form')); ?>"><button class="btn btn-primary" type="button">Business Loan Top-Up </button></a>
        </div>
        <div class="col-md-3">
          <a href="<?php echo e(url('/home_loan_form')); ?>"><button class="btn btn-primary" type="button">Home Loan Top-Up</button></a>
        </div>
        <div class="col-md-3">
          <a href="<?php echo e(url('/pos_based_loan_form')); ?>"><button class="btn btn-primary" type="button">POS Based Loan Top-Up </button></a>
        </div>
      </div>
    </div>

    <nav class="navbar navbar-expand navbar-light bg-light">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav menu mr-auto">
            <li class="nav-item">
              <a class="nav-link menu-btn" href="#about">Overview <span class="sr-only">(current)</span></a>
            </li>
            
          </ul>
        </div>
    </nav>

    <div class="menu-content about" style="color:black;">
        <div class="jumbotron">
            <b>Top-up loan</b> or <b>Balance transfer</b> is the loan one takes over and above an already existing loan. The existing loan could either be a home loan, a personal loan, or any other form of loan. Timely payments on the existing loan favor your chances of getting a top-up loan.<br>
            It is an add-on facility offered by lenders to their existing customer of all kind of loans like <a href="<?php echo e(url('/personal_loan_form')); ?>">Personal loans</a>, <a href="<?php echo e(url('/business_loan_form')); ?>">Business loans</a>, <a href="<?php echo e(url('/home_loan_form')); ?>">Home loans</a>, <a href="<?php echo e(url('/loan_against_property_form')); ?>">Loan against property</a>, <a href="<?php echo e(url('/credit_card_balance_transfer_form')); ?>">credit card</a>, etc.<br><br>

            <h5>Benefits of Top up loan</h5>
            <ul>
                <li><b>Lower interest rates:</b><br>
                        The most common benefit on loan top up is reduced interest rate; it leads to lower EMI and hence more monthly savings.
                <li><b>Maintain Credit Score</b><br>
                        Brought down interest will make it simpler for the cardholders to make payment and hence stabilize their credit score. They can even improve it with timely payments.
                <li><b>Transfer multiple accounts</b><br>
                        It helps in transferring all existing similar loans to a single account. Now the borrower can convert & payback all credit card debts from one place.
            </ul>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript">
        var $content = $('.menu-content');
    
        function showContent(type) {
          $content.hide().filter('.' + type).show();
        }
    
        $('.menu').on('click', '.menu-btn', function(e) {
          showContent(e.currentTarget.hash.slice(1));
          e.preventDefault();
        }); 
    
        // show 'about' content only on page load (if you want)
        showContent('about');
    </script>
    <small style="color: aliceblue">*(Subject to change as per financial institution’s discretion from time to time)</small>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/forms/topup_loan_form.blade.php ENDPATH**/ ?>