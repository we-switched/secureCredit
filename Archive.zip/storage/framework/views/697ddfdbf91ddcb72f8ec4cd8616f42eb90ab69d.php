<?php $__env->startComponent('mail::message'); ?>

Service : <?php echo e($service); ?>

Name : **<?php echo e($name); ?>**  
Email address : <?php echo e($email); ?>  
Phone : <?php echo e($phone); ?>  

<?php echo $__env->renderComponent(); ?><?php /**PATH /home/u181465707/domains/securecredit.in/securecredit/resources/views/common/notification.blade.php ENDPATH**/ ?>