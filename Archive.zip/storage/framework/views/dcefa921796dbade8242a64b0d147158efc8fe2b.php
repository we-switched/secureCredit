

<?php $__env->startSection('title', 'Career'); ?>

<?php $__env->startSection('content'); ?>

<div class="alert alert-info" role="alert">
    We have no job openings currently. Thank you for your time.
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u181465707/domains/securecredit.in/securecredit/resources/views/common/career.blade.php ENDPATH**/ ?>