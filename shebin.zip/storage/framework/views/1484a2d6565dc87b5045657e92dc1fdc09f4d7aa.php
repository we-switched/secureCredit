<?php $__env->startComponent('mail::message'); ?>
Hello **<?php echo e($name); ?>**,  
We see you have applied for a <?php echo e($service); ?>.
Thank you for choosing Secure Credit!

We are reviewing your application and will get back to you shortly.

Sincerely,  
Secure Credit team.
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/common/mail.blade.php ENDPATH**/ ?>