<?php $__env->startSection('title', 'Business Loan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top: 20px">
    <form method="POST" action="<?php echo e(url('/business_loan_form/'.$loan->id)); ?>" style="color: whitesmoke">
    <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?><div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="name" placeholder="Enter your name (as per PAN card)" name="name" value="<?php echo e(old('name', $loan->name)); ?>" required>
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="email">Email address</label>
            <input type="email" class="form-control custom-mine <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" placeholder="Enter your email address" name="email" value="<?php echo e(old('email', $loan->email)); ?>" required>
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="phone">Phone No.</label>
            <input type="text" class="form-control custom-mine <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phone" placeholder="Enter your phone no." name="phone" value="<?php echo e(old('phone', $loan->phone)); ?>" required>
            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <?php if(auth()->user()->role === "Admin"): ?>
        <p>Telecaller</p>
        <select class="custom-select custom-mine" name="telecaller" required>
            <option>Choose ... </option>
            <?php $__currentLoopData = $telecallers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telecaller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($telecaller->name); ?>" <?php echo e(($telecaller->name == $loan->telecaller) ? 'selected' : ''); ?>><?php echo e($telecaller->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <?php endif; ?>

        <p>Status</p>
        <select class="custom-select custom-mine" name="status" required>
            <option value="">Choose ...</option>
            <option value="Not Called" <?php echo e($loan->status == "Not Called" ? 'selected' : ''); ?>>Not Called</option>
            <option value="Not Doable" <?php echo e($loan->status == "Not Doable" ? 'selected' : ''); ?>>Not Doable</option>
            <option value="Not Eligible" <?php echo e($loan->status == "Not Eligible" ? 'selected' : ''); ?>>Not Eligible</option>
            <option value="Not Reachable" <?php echo e($loan->status == "Not Reachable" ? 'selected' : ''); ?>>Not Reachable</option>
            <option value="Not Interested" <?php echo e($loan->status == "Not Interested" ? 'selected' : ''); ?>>Not Interested</option>
            <option value="Wrong no." <?php echo e($loan->status == "Wrong no." ? 'selected' : ''); ?>>Wrong no.</option>
            <option value="Ringing" <?php echo e($loan->status == "Ringing" ? 'selected' : ''); ?>>Ringing</option>
            <option value="Follow Up" <?php echo e($loan->status == "Follow Up" ? 'selected' : ''); ?>>Follow Up</option>
            <option value="Meeting" <?php echo e($loan->status == "Meeting" ? 'selected' : ''); ?>>Meeting</option>
            <option value="DOC Pickup" <?php echo e($loan->status == "DOC Pickup" ? 'selected' : ''); ?>>DOC Pickup</option>
            <option value="Login" <?php echo e($loan->status == "Login" ? 'selected' : ''); ?>>Login</option>
            <option value="Rejected" <?php echo e($loan->status == "Rejected" ? 'selected' : ''); ?>>Rejected</option>
            <option value="Sanctioned" <?php echo e($loan->status == "Sanctioned" ? 'selected' : ''); ?>>Sanctioned</option>
            <option value="Disbursed" <?php echo e($loan->status == "Disbursed" ? 'selected' : ''); ?>>Disbursed</option>
            <option value="Repeated Lead" <?php echo e($loan->status == "Repeated Lead" ? 'selected' : ''); ?>>Repeated Lead</option>
        </select><br><br>

        <p>Select City</p>
        <select class="custom-select custom-mine" name="city" required>
            <option value="">Choose ...</option>
            <option value="Ahmedabad" <?php echo e($loan->city == "Ahmedabad" ? 'selected' : ''); ?>>Ahmedabad</option>
            <option value="Bangalore" <?php echo e($loan->city == "Bangalore" ? 'selected' : ''); ?>>Bangalore</option>
            <option value="Chennai" <?php echo e($loan->city == "Chennai" ? 'selected' : ''); ?>>Chennai</option>
            <option value="Coimbatore" <?php echo e($loan->city == "Coimbatore" ? 'selected' : ''); ?>>Coimbatore</option>
            <option value="Delhi" <?php echo e($loan->city == "Delhi" ? 'selected' : ''); ?>>Delhi</option>
            <option value="Delhi NCR" <?php echo e($loan->city == "Delhi NCR" ? 'selected' : ''); ?>>Delhi NCR</option>
            <option value="Hyderabad" <?php echo e($loan->city == "Hyderabad" ? 'selected' : ''); ?>>Hyderabad</option>
            <option value="Indore" <?php echo e($loan->city == "Indore" ? 'selected' : ''); ?>>Indore</option>
            <option value="Kochi" <?php echo e($loan->city == "Kochi" ? 'selected' : ''); ?>>Kochi</option>
            <option value="Mumbai" <?php echo e($loan->city == "Mumbai" ? 'selected' : ''); ?>>Mumbai</option>
            <option value="Mysore" <?php echo e($loan->city == "Mysore" ? 'selected' : ''); ?>>Mysore</option>
            <option value="Noida" <?php echo e($loan->city == "Noida" ? 'selected' : ''); ?>>Noida</option>
            <option value="Pune" <?php echo e($loan->city == "Pune" ? 'selected' : ''); ?>>Pune</option>
            <option value="Trivandrum" <?php echo e($loan->city == "Trivandrum" ? 'selected' : ''); ?>>Trivandrum</option>
            <option value="Vizag" <?php echo e($loan->city == "Vizag" ? 'selected' : ''); ?>>Vizag</option>
        </select><br><br>
       
        <p>Is it a Top-Up Loan ?</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="topup" value="No" <?php echo e($loan->topup == "No" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="topupno">No</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="topup" value="Yes" <?php echo e($loan->topup == "Yes" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="topupyes">Yes</label>
        </div><br>

        <p>Have you availed moratorium offered by RBI ?</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="moratorium" value="No" id="moratoriumno" <?php echo e($loan->moratorium == "No" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="moratoriumno">No</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="moratorium" value="Yes" id="moratoriumyes" <?php echo e($loan->moratorium == "Yes" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="moratoriumyes">Yes</label>
        </div><br>

        <div class="form-group">
            <label for="presentaddress">Present Address</label>
            <textarea class="form-control custom-mine <?php if ($errors->has('presentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="presentaddress" placeholder="Enter your present address" name="presentaddress" value="<?php echo e(old('presentaddress')); ?>" required><?php echo e(Request::old('presentaddress', $loan->presentaddress)); ?></textarea>
            <?php if ($errors->has('presentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentaddress'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>    
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="permanentaddress">Permanent Address</label>
            <textarea class="form-control custom-mine <?php if ($errors->has('permanentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('permanentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="permanentaddress" placeholder="Enter your permanent address" name="permanentaddress" value="<?php echo e(old('permanentaddress')); ?>" required><?php echo e(Request::old('permanentaddress', $loan->permanentaddress)); ?></textarea>
            <?php if ($errors->has('permanentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('permanentaddress'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="officeaddress">Office Address</label>
            <textarea class="form-control custom-mine <?php if ($errors->has('officeaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="officeaddress" placeholder="Enter your office address" name="officeaddress" value="<?php echo e(old('officeaddress')); ?>" required><?php echo e(Request::old('officeaddress', $loan->officeaddress)); ?></textarea>
            <?php if ($errors->has('officeaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeaddress'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="yearsinbusiness">No. of years in business</label>
            <input type="number" class="form-control custom-mine <?php if ($errors->has('yearsinbusiness')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinbusiness'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearsinbusiness" placeholder="Enter no. of years in business" name="yearsinbusiness" value="<?php echo e(old('yearsinbusiness', $loan->yearsinbusiness)); ?>" required>
            <?php if ($errors->has('yearsinbusiness')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinbusiness'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="yearsinblr">No. of years in Bengaluru</label>
            <input type="number" class="form-control custom-mine <?php if ($errors->has('yearsinblr')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinblr'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearsinblr" placeholder="Enter no. of years in Bengaluru" name="yearsinblr" value="<?php echo e(old('yearsinblr', $loan->yearsinblr)); ?>" required>
            <?php if ($errors->has('yearsinblr')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinblr'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="yearsinpresentaddress">No. of years in present address</label>
            <input type="number" class="form-control custom-mine <?php if ($errors->has('yearsinpresentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinpresentaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="yearsinpresentaddress" placeholder="Enter no. of years in present address" name="yearsinpresentaddress" value="<?php echo e(old('yearsinpresentaddress', $loan->yearsinpresentaddress)); ?>" required>
            <?php if ($errors->has('yearsinpresentaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearsinpresentaddress'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div><br>

        <p> Type of residence </p>
        <div class="form-check" required>
            <input class="form-check-input" type="radio" name="residence" id="rented" value="Rented" <?php echo e($loan->residence == "Rented" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="rented">Rented</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="residence" id="owned" value="Owned" <?php echo e($loan->residence == "Rented" ? 'Owned' : ''); ?>>
            <label class="form-check-label" for="owned">Owned</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="residence" id="parentsowned" value="Parents Owned" <?php echo e($loan->residence == "Rented" ? 'Parents Owned' : ''); ?>>
            <label class="form-check-label" for="parentsowned">Parents Owned</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="residence" id="other" value="Other" <?php echo e($loan->residence == "Other" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="other">Other</label>
        </div> <br>

        <p>Any existing loans</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="existingloans" id="yes" value="Yes" <?php echo e($loan->existingloans == "Yes" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="yes">Yes</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="existingloans" id="no" value="No" <?php echo e($loan->existingloans == "No" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="no">No</label>
        </div><br>

        <div class="form-group">
            <label for="turnover">Last year's turnover as per ITR</label>
            <input type="number" class="form-control custom-mine <?php if ($errors->has('turnover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('turnover'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="turnover" placeholder="Enter last year's turnover as per ITR" name="turnover" value="<?php echo e(old('turnover', $loan->turnover)); ?>" required>
            <?php if ($errors->has('turnover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('turnover'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label for="profit">Last year's net profit as per ITR</label>
            <input type="number" class="form-control custom-mine <?php if ($errors->has('profit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('profit'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="profit" placeholder="Enter last year's net profit as per ITR" name="profit" value="<?php echo e(old('profit', $loan->profit)); ?>" required>
            <?php if ($errors->has('profit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('profit'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div><br>

        <p>Marital Status</p>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="maritalstatus" id="married" value="Married" <?php echo e($loan->maritalstatus == "Married" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="married">Married</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="maritalstatus" id="single" value="Single" <?php echo e($loan->maritalstatus == "Single" ? 'checked' : ''); ?>>
            <label class="form-check-label" for="single">Single</label>
        </div><br>

        <p>Type of Company</p>
            <select class="custom-select custom-mine" name="company" required>
            <option selected>Choose ...</option>
            <option value="Private Ltd." <?php echo e($loan->company == "Private Ltd." ? 'selected' : ''); ?>>Private Ltd.</option>
            <option value="Proprietorship" <?php echo e($loan->company == "Proprietorship" ? 'selected' : ''); ?>>Proprietorship</option>
            <option value="Partnership" <?php echo e($loan->company == "Partnership" ? 'selected' : ''); ?>>Partnership</option>
            <option value="LLC" <?php echo e($loan->company == "LLC" ? 'selected' : ''); ?>>LLC</option>
            <option value="LLP" <?php echo e($loan->company == "LLP" ? 'selected' : ''); ?>>LLP</option>
        </select><br>

        <center><button type="submit" class="btn btn-primary">Submit</button></center>

    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shebin\resources\views/edit/business_loan_form.blade.php ENDPATH**/ ?>