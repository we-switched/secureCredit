@component('mail::message')

Service : {{$service}}
Name : **{{$name}}**  {{-- use double space for line break --}}
Email address : {{$email}}  
Phone : {{$phone}}  

@endcomponent